#!/usr/bin/env bash
set -euo pipefail
TARGET_DIR="${1:-$(pwd)}"
UPDATE_DIR="${2:-$(pwd)/update}"
BACKUP_ROOT="${3:-$(pwd)/backup-$(date +%Y%m%d-%H%M%S)}"
[ -d "$TARGET_DIR" ] || { echo "[ERROR] Missing target: $TARGET_DIR"; exit 1; }
[ -d "$UPDATE_DIR" ] || { echo "[ERROR] Missing update dir: $UPDATE_DIR"; exit 1; }
mkdir -p "$BACKUP_ROOT"
while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  src="$TARGET_DIR/$rel"
  if [ -e "$src" ]; then
    mkdir -p "$BACKUP_ROOT/$(dirname "$rel")"
    cp -a "$src" "$BACKUP_ROOT/$rel"
  fi
done < <(cd "$UPDATE_DIR" && find . -type f | sed 's#^./##')
cp -a "$UPDATE_DIR/." "$TARGET_DIR/"
echo "[OK] Files replaced"
