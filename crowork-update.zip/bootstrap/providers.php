<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\AdminadminPanelProvider::class,
    App\Providers\Filament\EmployerPanelProvider::class,
];
