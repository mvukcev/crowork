<x-app-layout>
    <x-slot name="title">{{ $education->title }}</x-slot>
    <x-slot name="description">{{ \Illuminate\Support\Str::limit(strip_tags($education->description), 150) }}</x-slot>
    <x-slot name="canonical">{{ route('educations.show', $education) }}</x-slot>

    @php
        $breadcrumbSchema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => __('ui.navigation.home'),
                    'item' => route('home'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => __('ui.navigation.educations'),
                    'item' => route('educations.index'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $education->title,
                    'item' => route('educations.show', $education),
                ],
            ],
        ];
    @endphp

    @push('head')
        <script type="application/ld+json">{!! json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
    @endpush

    <section class="cw-section">
        <div class="cw-container">
            <div class="mb-6 text-sm text-slate-500">
                <a href="{{ route('home') }}" class="hover:text-slate-900">{{ __('ui.navigation.home') }}</a>
                <span class="mx-1">/</span>
                <a href="{{ route('educations.index') }}" class="hover:text-slate-900">{{ __('ui.navigation.educations') }}</a>
                <span class="mx-1">/</span>
                <span class="text-slate-700">{{ $education->title }}</span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <article class="lg:col-span-2 cw-surface p-6 md:p-7">
                    <p class="text-xs text-slate-500 mb-1">{{ $provider ?? ($education->createdByUser?->name ?? __('ui.educations_show.provider_fallback')) }}</p>
                    <h1 class="cw-display text-4xl md:text-6xl mb-3">{{ $education->title }}</h1>
                    <p class="text-sm text-slate-500 mb-4">{{ __('ui.educations_show.posted_prefix') }} {{ $postedDisplay ?? ($education->published_at?->diffForHumans() ?? $education->created_at?->diffForHumans()) }}</p>
                    <div class="prose max-w-none text-slate-700 leading-relaxed">{!! nl2br(e($education->description)) !!}</div>
                </article>

                <aside class="cw-surface p-5">
                    <h2 class="text-lg font-semibold text-slate-900 mb-3">{{ __('ui.educations_show.details_heading') }}</h2>
                    <p class="text-sm text-slate-700 mb-2"><strong>{{ __('ui.educations_show.location_label') }}</strong> {{ $locationDisplay ?? ($education->is_online ? __('ui.educations_show.online') : ($education->city ?: __('ui.educations_show.default_country'))) }}</p>
                    <p class="text-sm text-slate-700 mb-2"><strong>{{ __('ui.educations_show.price_label') }}</strong> {{ $priceDisplay ?? (($education->currency ?? 'EUR') . ' ' . number_format(($education->price_cents ?? 0) / 100, 2)) }}</p>
                    @if($education->start_date)
                        <p class="text-sm text-slate-700 mb-2"><strong>{{ __('ui.educations_show.start_label') }}</strong> {{ $startDateDisplay ?? $education->start_date->translatedFormat('j M Y') }}</p>
                    @endif
                    @if($education->capacity)
                        <p class="text-sm text-slate-700 mb-2"><strong>{{ __('ui.educations_show.capacity_label') }}</strong> {{ $education->capacity }}</p>
                    @endif

                    <a href="{{ route('educations.apply', $education) }}" class="cw-button-primary w-full mt-3" data-cw-track-click="apply_start">{{ __('ui.educations_show.apply_now') }}</a>
                </aside>
            </div>
        </div>
    </section>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('education_view', {
                    education_slug: @json($education->slug),
                    provider: @json($provider ?? ($education->createdByUser?->name ?? null))
                });
            });
        </script>
    @endpush
</x-app-layout>
