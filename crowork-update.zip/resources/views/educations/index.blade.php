<x-app-layout>
    <x-slot name="title">{{ __('ui.educations_page.page_title') }}</x-slot>
    <x-slot name="description">{{ __('ui.educations_page.page_description') }}</x-slot>
    <x-slot name="canonical">{{ route('educations.index') }}</x-slot>

    @push('head')
        @if($educations->previousPageUrl())
            <link rel="prev" href="{{ $educations->previousPageUrl() }}">
        @endif
        @if($educations->nextPageUrl())
            <link rel="next" href="{{ $educations->nextPageUrl() }}">
        @endif
    @endpush

    <section class="cw-section">
        <div class="cw-container">
            <div class="cw-content-wide mb-8">
                <p class="cw-kicker mb-2">{{ __('ui.navigation.educations') }}</p>
                <h1 class="cw-display text-3xl md:text-5xl mb-3">{!! __('ui.educations_page.hero_headline') !!}</h1>
                <p class="text-base text-slate-600 max-w-2xl">{{ __('ui.educations_page.hero_subheadline') }}</p>
            </div>

            @php
                $removeFilterQuery = function (string $key): array {
                    $query = request()->query();
                    unset($query[$key], $query['page']);

                    return $query;
                };

                $activeChips = [];

                if (filled($filters['q'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.search_chip', ['value' => $filters['q']]),
                        'href' => route('educations.index', $removeFilterQuery('q')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['city'] ?? null)) {
                    $activeChips[] = [
                        'label' => (string) $filters['city'],
                        'href' => route('educations.index', $removeFilterQuery('city')),
                        'tone' => 'blue',
                    ];
                }

                if (request()->input('is_online') == '1') {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.online_only_label'),
                        'href' => route('educations.index', $removeFilterQuery('is_online')),
                        'tone' => 'orange',
                    ];
                }

                if (filled($filters['start_from'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.starts_from_chip', [
                            'date' => \Illuminate\Support\Carbon::parse((string) $filters['start_from'])->translatedFormat('j M Y'),
                        ]),
                        'href' => route('educations.index', $removeFilterQuery('start_from')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['price_max'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.up_to_eur_chip', ['amount' => number_format((int) $filters['price_max'])]),
                        'href' => route('educations.index', $removeFilterQuery('price_max')),
                        'tone' => 'orange',
                    ];
                }
            @endphp

            <form
                method="GET"
                action="{{ route('educations.index') }}"
                data-cw-filter-form
                data-cw-filter-panel-id="education-advanced-filters"
                data-cw-track-submit="education_search"
                class="mb-6"
                x-data="{
                    desktopAdvancedOpen: false,
                    mobilePanelOpen: false,
                    submitting: false,
                    isDesktop() {
                        return window.matchMedia('(min-width: 768px)').matches;
                    },
                    shouldShowPanel() {
                        return this.isDesktop() ? this.desktopAdvancedOpen : this.mobilePanelOpen;
                    },
                    closePanel() {
                        this.desktopAdvancedOpen = false;
                        this.mobilePanelOpen = false;
                    }
                }"
                @submit="submitting = true"
                @keydown.escape.window="closePanel()"
            >
                <div class="cw-filter-shell">
                    <div class="cw-surface p-3 md:p-4">
                        <div class="flex items-center justify-between gap-3 mb-3">
                            <div class="text-sm text-slate-600">
                                <span class="font-semibold text-slate-900">{{ number_format($educations->total()) }}</span>
                                <span>{{ trans_choice('ui.educations_page.filter_results_count', $educations->total()) }}</span>
                            </div>
                            @if(count($activeChips) > 0)
                                <a href="{{ route('educations.index') }}" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-track-click="education_filter_reset">{{ __('ui.educations_page.clear_all_filters') }}</a>
                            @endif
                        </div>

                        <div class="cw-filter-topbar">
                            <div>
                                <label class="cw-label" for="q">{{ __('ui.educations_page.search_button') }}</label>
                                <input id="q" name="q" value="{{ $filters['q'] ?? request('q') }}" class="cw-field" placeholder="{{ __('ui.educations_page.search_placeholder') }}">
                            </div>
                            <div>
                                <label class="cw-label" for="city">{{ __('ui.educations_page.city_label') }}</label>
                                <select id="city" name="city" class="cw-field">
                                    <option value="">{{ __('ui.educations_page.all_cities') }}</option>
                                    @foreach($cities as $city)
                                        <option value="{{ $city }}" @selected(($filters['city'] ?? request('city')) === $city)>{{ $city }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="flex items-end gap-2">
                                <button
                                    class="cw-button-primary min-w-[120px]"
                                    type="submit"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="{{ __('ui.educations_page.search_button') }}" data-loading-label="{{ __('ui.educations_page.updating_results') }}" aria-live="polite">{{ __('ui.educations_page.search_button') }}</span>
                                </button>
                                <button
                                    type="button"
                                    class="cw-button-secondary hidden md:inline-flex"
                                    data-cw-filter-toggle
                                    aria-controls="education-advanced-filters"
                                    :aria-expanded="desktopAdvancedOpen ? 'true' : 'false'"
                                    @click="desktopAdvancedOpen = !desktopAdvancedOpen"
                                    data-cw-track-click="education_filter_open"
                                >
                                    <span>{{ __('ui.educations_page.filters_button') }}</span>
                                    <span class="ml-1 text-xs text-slate-500" x-text="desktopAdvancedOpen ? @js(__('ui.educations_page.toggle_hide')) : @js(__('ui.educations_page.toggle_show'))"></span>
                                </button>
                            </div>
                        </div>

                        <div class="md:hidden mt-3">
                            <button
                                type="button"
                                class="cw-button-secondary w-full"
                                data-cw-filter-open
                                @click="mobilePanelOpen = true"
                                    data-cw-track-click="education_filter_open"
                                aria-controls="education-advanced-filters"
                                :aria-expanded="mobilePanelOpen ? 'true' : 'false'"
                            >
                                {{ __('ui.educations_page.advanced_filters_title') }}
                            </button>
                        </div>

                        <p class="text-xs text-slate-500 mt-2" x-show="submitting" x-cloak aria-live="polite">{{ __('ui.educations_page.refreshing_results') }}</p>
                    </div>

                    <div class="md:hidden" x-cloak>
                        <div class="cw-filter-overlay" data-cw-filter-overlay x-show="mobilePanelOpen" x-transition.opacity @click="mobilePanelOpen = false"></div>
                    </div>

                    <div
                        id="education-advanced-filters"
                        x-cloak
                        x-show="shouldShowPanel()"
                        style="display: none;"
                        x-transition:enter="transition ease-out duration-200"
                        x-transition:enter-start="opacity-0 translate-y-2"
                        x-transition:enter-end="opacity-100 translate-y-0"
                        x-transition:leave="transition ease-in duration-150"
                        x-transition:leave-start="opacity-100 translate-y-0"
                        x-transition:leave-end="opacity-0 translate-y-2"
                        class="fixed md:relative inset-x-0 bottom-0 z-[70] md:z-auto"
                        :class="isDesktop() ? 'mt-3' : 'cw-filter-bottom-sheet'"
                    >
                        <div class="cw-filter-panel p-4 md:p-5" :class="isDesktop() ? '' : 'rounded-b-none border-b-0 pb-6'">
                            <div class="flex items-center justify-between mb-3 md:hidden">
                                <h2 class="text-sm font-semibold text-slate-900">{{ __('ui.educations_page.advanced_filters_title') }}</h2>
                                <button type="button" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-filter-close aria-controls="education-advanced-filters" @click="mobilePanelOpen = false">{{ __('ui.educations_page.close_filters') }}</button>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                                <div>
                                    <p class="cw-filter-heading">{{ __('ui.educations_page.format_label') }}</p>
                                    <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                        <input type="checkbox" name="is_online" value="1" class="rounded border-slate-300" @checked(($filters['is_online'] ?? request('is_online')))> 
                                        {{ __('ui.educations_page.online_only_label') }}
                                    </label>
                                </div>

                                <div>
                                    <p class="cw-filter-heading">{{ __('ui.educations_page.start_date_label') }}</p>
                                    <label class="cw-label" for="start_from">{{ __('ui.educations_page.start_date_label') }}</label>
                                    <input id="start_from" name="start_from" value="{{ $filters['start_from'] ?? request('start_from') }}" class="cw-field" type="date">
                                </div>

                                <div>
                                    <p class="cw-filter-heading">{{ __('ui.educations_page.pricing_section') }}</p>
                                    <label class="cw-label" for="price_max">{{ __('ui.educations_page.price_max_label') }}</label>
                                    <input id="price_max" name="price_max" value="{{ $filters['price_max'] ?? request('price_max') }}" class="cw-field" type="number" min="0" step="1" placeholder="{{ __('ui.educations_page.price_placeholder') }}">
                                </div>
                            </div>

                            <div class="mt-5 flex flex-wrap items-center gap-2">
                                <button
                                    class="cw-button-primary"
                                    type="submit"
                                    data-cw-track-click="education_filter_apply"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="{{ __('ui.educations_page.apply_filters') }}" data-loading-label="{{ __('ui.educations_page.applying_filters') }}" aria-live="polite">{{ __('ui.educations_page.apply_filters') }}</span>
                                </button>
                                <a href="{{ route('educations.index') }}" class="cw-button-secondary" data-cw-track-click="education_filter_reset">{{ __('ui.educations_page.clear_all_filters') }}</a>
                                <button type="button" class="cw-button-secondary md:hidden" data-cw-filter-close aria-controls="education-advanced-filters" @click="mobilePanelOpen = false">{{ __('ui.educations_page.done_filters') }}</button>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="button" class="cw-button-primary cw-filter-fab md:hidden" data-cw-filter-open aria-controls="education-advanced-filters" @click="mobilePanelOpen = true">
                    {{ __('ui.educations_page.filters_button') }}
                </button>
            </form>

            @if(count($activeChips) > 0)
                <div class="mb-5 flex flex-wrap items-center gap-2">
                    @foreach($activeChips as $chip)
                        <x-filter-chip :href="$chip['href']" :label="$chip['label']" :tone="$chip['tone']" />
                    @endforeach
                    <a href="{{ route('educations.index') }}" class="cw-button-secondary !px-3 !py-2 text-xs">{{ __('ui.educations_page.clear_all_filters') }}</a>
                </div>
            @endif

            @if(count($activeChips) === 0)
                <!-- Why CroWork Education section -->
                <div class="mb-8">
                    <h2 class="text-2xl md:text-3xl font-semibold text-slate-900 mb-6">{{ __('ui.educations_page.why_crowork_title') }}</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                        <!-- Practical learning -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-indigo-100">
                                        <svg class="h-6 w-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1">{{ __('ui.educations_page.why_crowork.practical_title') }}</h3>
                                    <p class="text-sm text-slate-600">{{ __('ui.educations_page.why_crowork.practical_desc') }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- Career growth -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-blue-100">
                                        <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1">{{ __('ui.educations_page.why_crowork.career_title') }}</h3>
                                    <p class="text-sm text-slate-600">{{ __('ui.educations_page.why_crowork.career_desc') }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- Workplace integration -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-purple-100">
                                        <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-2a6 6 0 0112 0v2zm0 0h6v-2a6 6 0 00-9-5.656v2.656A4 4 0 0115 21z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1">{{ __('ui.educations_page.why_crowork.integration_title') }}</h3>
                                    <p class="text-sm text-slate-600">{{ __('ui.educations_page.why_crowork.integration_desc') }}</p>
                                </div>
                            </div>
                        </div>

                        <!-- Build confidence -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-emerald-100">
                                        <svg class="h-6 w-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1">{{ __('ui.educations_page.why_crowork.confidence_title') }}</h3>
                                    <p class="text-sm text-slate-600">{{ __('ui.educations_page.why_crowork.confidence_desc') }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @include('educations._results', ['educations' => $educations])
        </div>
    </section>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('education_search_results_view', {
                    page: {{ $educations->currentPage() }},
                    total_results: {{ $educations->total() }}
                });
            });
        </script>
    @endpush
</x-app-layout>
