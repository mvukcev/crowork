<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'cw-button-primary cw-press'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/components/primary-button.blade.php ENDPATH**/ ?>