<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Notifications <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container cw-content-wide">
            <div class="flex items-center justify-between gap-3 mb-6">
                <div>
                    <p class="cw-kicker mb-1">Notification center</p>
                    <h1 class="cw-display text-4xl md:text-5xl">Your notifications</h1>
                    <p class="text-sm text-slate-600 mt-2">Unread: <?php echo e($unreadCount); ?></p>
                </div>
                <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>" data-cw-track-submit="notification_mark_all_read">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="cw-button-secondary">Mark all as read</button>
                </form>
                <a href="<?php echo e(route('notifications.preferences')); ?>" class="cw-button-secondary" data-cw-track-click="navigation_click">Preferences</a>
            </div>

            <div class="flex gap-2 mb-4">
                <a href="<?php echo e(route('notifications.index', ['filter' => 'all'])); ?>" class="cw-button-secondary <?php echo e($filter === 'all' ? 'border-slate-400' : ''); ?>">All</a>
                <a href="<?php echo e(route('notifications.index', ['filter' => 'unread'])); ?>" class="cw-button-secondary <?php echo e($filter === 'unread' ? 'border-slate-400' : ''); ?>">Unread</a>
                <a href="<?php echo e(route('notifications.index', ['filter' => 'important'])); ?>" class="cw-button-secondary <?php echo e($filter === 'important' ? 'border-slate-400' : ''); ?>">Important notices</a>
            </div>

            <div class="cw-surface overflow-hidden">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notifications->count() === 0): ?>
                    <div class="p-8 text-center text-slate-600">No notifications found.</div>
                <?php else: ?>
                    <div class="divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $payload = $notification->data;
                                $title = $payload['title'] ?? class_basename($notification->type);
                                $message = $payload['message'] ?? 'You have a new notification.';
                                $url = $payload['url'] ?? route('notifications.index');
                                $category = $payload['category'] ?? 'general';
                                $importance = $payload['importance'] ?? 'normal';
                            ?>
                            <article class="p-4 <?php echo e($notification->read_at ? 'bg-white' : 'bg-blue-50/40'); ?>">
                                <div class="flex items-start justify-between gap-3">
                                    <div>
                                        <div class="flex items-center gap-2 mb-1">
                                            <h2 class="text-sm font-semibold text-slate-900"><?php echo e($title); ?></h2>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($importance === 'high'): ?>
                                                <span class="inline-flex text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">Important</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <span class="inline-flex text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full bg-slate-100 text-slate-600"><?php echo e(str_replace('_', ' ', $category)); ?></span>
                                        </div>
                                        <p class="text-sm text-slate-700"><?php echo e($message); ?></p>
                                        <p class="text-xs text-slate-500 mt-1"><?php echo e($notification->created_at?->diffForHumans()); ?></p>
                                    </div>
                                    <div class="flex flex-col sm:flex-row gap-2">
                                        <a href="<?php echo e(route('notifications.open', $notification->id)); ?>" class="cw-button-secondary" data-cw-track-click="notification_open">Open</a>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($notification->read_at === null): ?>
                                            <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="cw-button-secondary">Mark as read</button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="p-4"><?php echo e($notifications->links()); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/notifications/index.blade.php ENDPATH**/ ?>