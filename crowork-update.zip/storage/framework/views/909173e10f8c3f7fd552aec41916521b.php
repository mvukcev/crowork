<?php
    $body = $body ?? '';
?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'CroWork')); ?></title>
</head>
<body style="font-family: Arial, sans-serif; color: #0f172a; line-height: 1.6; margin: 0; padding: 24px;">
<div style="max-width: 680px; margin: 0 auto;">
    <?php echo nl2br(e($body)); ?>

</div>
</body>
</html>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/mail/dynamic-template.blade.php ENDPATH**/ ?>