<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'provider' => null,
    'city' => null,
    'is_online' => false,
    'start_date' => null,
    'price_cents' => null,
    'currency' => 'EUR',
    'posted_at' => null,
    'href' => '#',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'provider' => null,
    'city' => null,
    'is_online' => false,
    'start_date' => null,
    'price_cents' => null,
    'currency' => 'EUR',
    'posted_at' => null,
    'href' => '#',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $priceDisplay = !is_null($price_cents) ? $currency . ' ' . number_format($price_cents / 100, 2) : __('educations.contact_provider');
?>

<a href="<?php echo e($href); ?>" class="cw-surface p-5 block cw-hover-lift">
    <p class="text-xs text-slate-500 mb-1"><?php echo e($provider ?: __('educations.provider_fallback')); ?></p>
    <h3 class="text-lg font-semibold text-slate-900 leading-tight mb-2"><?php echo e($title); ?></h3>
    <p class="text-sm text-slate-700 mb-3"><?php echo e($is_online ? __('educations.online_program') : ($city ?: __('educations.country_fallback'))); ?></p>

    <div class="flex flex-wrap gap-2">
        <span class="cw-chip"><?php echo e($priceDisplay); ?></span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($start_date): ?>
            <span class="cw-chip"><?php echo e(__('educations.starts_on', ['date' => \Carbon\Carbon::parse($start_date)->format('M j, Y')])); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($posted_at): ?>
            <span class="cw-chip"><?php echo e(__('educations.posted_short', ['time' => \Carbon\Carbon::parse($posted_at)->diffForHumans()])); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</a>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/components/education-card.blade.php ENDPATH**/ ?>