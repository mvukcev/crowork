<?php
    use App\Services\AnalyticsConfigService;
    use App\Services\MetaPixelConfigService;
    use App\Services\ConsentConfigService;
?>


<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(AnalyticsConfigService::shouldInjectGTM() && ConsentConfigService::isAnalyticsAllowed()): ?>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e(AnalyticsConfigService::getGoogleTagManagerId()); ?>"
                height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(MetaPixelConfigService::shouldInjectPixel() && ConsentConfigService::isMarketingAllowed()): ?>
    <!-- Meta Pixel (noscript) -->
    <noscript>
        <img height="1" width="1" style="display:none" 
             src="https://www.facebook.com/tr?id=<?php echo e(MetaPixelConfigService::getPixelId()); ?>&ev=PageView&noscript=1" />
    </noscript>
    <!-- End Meta Pixel (noscript) -->
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/components/analytics-noscript.blade.php ENDPATH**/ ?>