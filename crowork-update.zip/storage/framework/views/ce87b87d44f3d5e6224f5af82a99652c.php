<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('ui.educations_page.page_title')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(__('ui.educations_page.page_description')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('educations.index')); ?> <?php $__env->endSlot(); ?>

    <?php $__env->startPush('head'); ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($educations->previousPageUrl()): ?>
            <link rel="prev" href="<?php echo e($educations->previousPageUrl()); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($educations->nextPageUrl()): ?>
            <link rel="next" href="<?php echo e($educations->nextPageUrl()); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php $__env->stopPush(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="cw-content-wide mb-8">
                <p class="cw-kicker mb-2"><?php echo e(__('ui.navigation.educations')); ?></p>
                <h1 class="cw-display text-3xl md:text-5xl mb-3"><?php echo __('ui.educations_page.hero_headline'); ?></h1>
                <p class="text-base text-slate-600 max-w-2xl"><?php echo e(__('ui.educations_page.hero_subheadline')); ?></p>
            </div>

            <?php
                $removeFilterQuery = function (string $key): array {
                    $query = request()->query();
                    unset($query[$key], $query['page']);

                    return $query;
                };

                $activeChips = [];

                if (filled($filters['q'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.search_chip', ['value' => $filters['q']]),
                        'href' => route('educations.index', $removeFilterQuery('q')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['city'] ?? null)) {
                    $activeChips[] = [
                        'label' => (string) $filters['city'],
                        'href' => route('educations.index', $removeFilterQuery('city')),
                        'tone' => 'blue',
                    ];
                }

                if (request()->input('is_online') == '1') {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.online_only_label'),
                        'href' => route('educations.index', $removeFilterQuery('is_online')),
                        'tone' => 'orange',
                    ];
                }

                if (filled($filters['start_from'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.starts_from_chip', [
                            'date' => \Illuminate\Support\Carbon::parse((string) $filters['start_from'])->translatedFormat('j M Y'),
                        ]),
                        'href' => route('educations.index', $removeFilterQuery('start_from')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['price_max'] ?? null)) {
                    $activeChips[] = [
                        'label' => __('ui.educations_page.up_to_eur_chip', ['amount' => number_format((int) $filters['price_max'])]),
                        'href' => route('educations.index', $removeFilterQuery('price_max')),
                        'tone' => 'orange',
                    ];
                }
            ?>

            <form
                method="GET"
                action="<?php echo e(route('educations.index')); ?>"
                data-cw-filter-form
                data-cw-filter-panel-id="education-advanced-filters"
                data-cw-track-submit="education_search"
                class="mb-6"
                x-data="{
                    desktopAdvancedOpen: false,
                    mobilePanelOpen: false,
                    submitting: false,
                    isDesktop() {
                        return window.matchMedia('(min-width: 768px)').matches;
                    },
                    shouldShowPanel() {
                        return this.isDesktop() ? this.desktopAdvancedOpen : this.mobilePanelOpen;
                    },
                    closePanel() {
                        this.desktopAdvancedOpen = false;
                        this.mobilePanelOpen = false;
                    }
                }"
                @submit="submitting = true"
                @keydown.escape.window="closePanel()"
            >
                <div class="cw-filter-shell">
                    <div class="cw-surface p-3 md:p-4">
                        <div class="flex items-center justify-between gap-3 mb-3">
                            <div class="text-sm text-slate-600">
                                <span class="font-semibold text-slate-900"><?php echo e(number_format($educations->total())); ?></span>
                                <span><?php echo e(trans_choice('ui.educations_page.filter_results_count', $educations->total())); ?></span>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($activeChips) > 0): ?>
                                <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-track-click="education_filter_reset"><?php echo e(__('ui.educations_page.clear_all_filters')); ?></a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="cw-filter-topbar">
                            <div>
                                <label class="cw-label" for="q"><?php echo e(__('ui.educations_page.search_button')); ?></label>
                                <input id="q" name="q" value="<?php echo e($filters['q'] ?? request('q')); ?>" class="cw-field" placeholder="<?php echo e(__('ui.educations_page.search_placeholder')); ?>">
                            </div>
                            <div>
                                <label class="cw-label" for="city"><?php echo e(__('ui.educations_page.city_label')); ?></label>
                                <select id="city" name="city" class="cw-field">
                                    <option value=""><?php echo e(__('ui.educations_page.all_cities')); ?></option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city); ?>" <?php if(($filters['city'] ?? request('city')) === $city): echo 'selected'; endif; ?>><?php echo e($city); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                            </div>
                            <div class="flex items-end gap-2">
                                <button
                                    class="cw-button-primary min-w-[120px]"
                                    type="submit"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="<?php echo e(__('ui.educations_page.search_button')); ?>" data-loading-label="<?php echo e(__('ui.educations_page.updating_results')); ?>" aria-live="polite"><?php echo e(__('ui.educations_page.search_button')); ?></span>
                                </button>
                                <button
                                    type="button"
                                    class="cw-button-secondary hidden md:inline-flex"
                                    data-cw-filter-toggle
                                    aria-controls="education-advanced-filters"
                                    :aria-expanded="desktopAdvancedOpen ? 'true' : 'false'"
                                    @click="desktopAdvancedOpen = !desktopAdvancedOpen"
                                    data-cw-track-click="education_filter_open"
                                >
                                    <span><?php echo e(__('ui.educations_page.filters_button')); ?></span>
                                    <span class="ml-1 text-xs text-slate-500" x-text="desktopAdvancedOpen ? <?php echo \Illuminate\Support\Js::from(__('ui.educations_page.toggle_hide'))->toHtml() ?> : <?php echo \Illuminate\Support\Js::from(__('ui.educations_page.toggle_show'))->toHtml() ?>"></span>
                                </button>
                            </div>
                        </div>

                        <div class="md:hidden mt-3">
                            <button
                                type="button"
                                class="cw-button-secondary w-full"
                                data-cw-filter-open
                                @click="mobilePanelOpen = true"
                                    data-cw-track-click="education_filter_open"
                                aria-controls="education-advanced-filters"
                                :aria-expanded="mobilePanelOpen ? 'true' : 'false'"
                            >
                                <?php echo e(__('ui.educations_page.advanced_filters_title')); ?>

                            </button>
                        </div>

                        <p class="text-xs text-slate-500 mt-2" x-show="submitting" x-cloak aria-live="polite"><?php echo e(__('ui.educations_page.refreshing_results')); ?></p>
                    </div>

                    <div class="md:hidden" x-cloak>
                        <div class="cw-filter-overlay" data-cw-filter-overlay x-show="mobilePanelOpen" x-transition.opacity @click="mobilePanelOpen = false"></div>
                    </div>

                    <div
                        id="education-advanced-filters"
                        x-cloak
                        x-show="shouldShowPanel()"
                        style="display: none;"
                        x-transition:enter="transition ease-out duration-200"
                        x-transition:enter-start="opacity-0 translate-y-2"
                        x-transition:enter-end="opacity-100 translate-y-0"
                        x-transition:leave="transition ease-in duration-150"
                        x-transition:leave-start="opacity-100 translate-y-0"
                        x-transition:leave-end="opacity-0 translate-y-2"
                        class="fixed md:relative inset-x-0 bottom-0 z-[70] md:z-auto"
                        :class="isDesktop() ? 'mt-3' : 'cw-filter-bottom-sheet'"
                    >
                        <div class="cw-filter-panel p-4 md:p-5" :class="isDesktop() ? '' : 'rounded-b-none border-b-0 pb-6'">
                            <div class="flex items-center justify-between mb-3 md:hidden">
                                <h2 class="text-sm font-semibold text-slate-900"><?php echo e(__('ui.educations_page.advanced_filters_title')); ?></h2>
                                <button type="button" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-filter-close aria-controls="education-advanced-filters" @click="mobilePanelOpen = false"><?php echo e(__('ui.educations_page.close_filters')); ?></button>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.educations_page.format_label')); ?></p>
                                    <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                        <input type="checkbox" name="is_online" value="1" class="rounded border-slate-300" <?php if(($filters['is_online'] ?? request('is_online'))): echo 'checked'; endif; ?>> 
                                        <?php echo e(__('ui.educations_page.online_only_label')); ?>

                                    </label>
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.educations_page.start_date_label')); ?></p>
                                    <label class="cw-label" for="start_from"><?php echo e(__('ui.educations_page.start_date_label')); ?></label>
                                    <input id="start_from" name="start_from" value="<?php echo e($filters['start_from'] ?? request('start_from')); ?>" class="cw-field" type="date">
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.educations_page.pricing_section')); ?></p>
                                    <label class="cw-label" for="price_max"><?php echo e(__('ui.educations_page.price_max_label')); ?></label>
                                    <input id="price_max" name="price_max" value="<?php echo e($filters['price_max'] ?? request('price_max')); ?>" class="cw-field" type="number" min="0" step="1" placeholder="<?php echo e(__('ui.educations_page.price_placeholder')); ?>">
                                </div>
                            </div>

                            <div class="mt-5 flex flex-wrap items-center gap-2">
                                <button
                                    class="cw-button-primary"
                                    type="submit"
                                    data-cw-track-click="education_filter_apply"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="<?php echo e(__('ui.educations_page.apply_filters')); ?>" data-loading-label="<?php echo e(__('ui.educations_page.applying_filters')); ?>" aria-live="polite"><?php echo e(__('ui.educations_page.apply_filters')); ?></span>
                                </button>
                                <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-secondary" data-cw-track-click="education_filter_reset"><?php echo e(__('ui.educations_page.clear_all_filters')); ?></a>
                                <button type="button" class="cw-button-secondary md:hidden" data-cw-filter-close aria-controls="education-advanced-filters" @click="mobilePanelOpen = false"><?php echo e(__('ui.educations_page.done_filters')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="button" class="cw-button-primary cw-filter-fab md:hidden" data-cw-filter-open aria-controls="education-advanced-filters" @click="mobilePanelOpen = true">
                    <?php echo e(__('ui.educations_page.filters_button')); ?>

                </button>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($activeChips) > 0): ?>
                <div class="mb-5 flex flex-wrap items-center gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $activeChips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-chip','data' => ['href' => $chip['href'],'label' => $chip['label'],'tone' => $chip['tone']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['href']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['label']),'tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['tone'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8)): ?>
<?php $attributes = $__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8; ?>
<?php unset($__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8)): ?>
<?php $component = $__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8; ?>
<?php unset($__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-secondary !px-3 !py-2 text-xs"><?php echo e(__('ui.educations_page.clear_all_filters')); ?></a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(count($activeChips) === 0): ?>
                <!-- Why CroWork Education section -->
                <div class="mb-8">
                    <h2 class="text-2xl md:text-3xl font-semibold text-slate-900 mb-6"><?php echo e(__('ui.educations_page.why_crowork_title')); ?></h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                        <!-- Practical learning -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-indigo-100">
                                        <svg class="h-6 w-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.educations_page.why_crowork.practical_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.educations_page.why_crowork.practical_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Career growth -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-blue-100">
                                        <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.educations_page.why_crowork.career_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.educations_page.why_crowork.career_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Workplace integration -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-purple-100">
                                        <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-2a6 6 0 0112 0v2zm0 0h6v-2a6 6 0 00-9-5.656v2.656A4 4 0 0115 21z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.educations_page.why_crowork.integration_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.educations_page.why_crowork.integration_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Build confidence -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-emerald-100">
                                        <svg class="h-6 w-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.educations_page.why_crowork.confidence_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.educations_page.why_crowork.confidence_desc')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo $__env->make('educations._results', ['educations' => $educations], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('education_search_results_view', {
                    page: <?php echo e($educations->currentPage()); ?>,
                    total_results: <?php echo e($educations->total()); ?>

                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/educations/index.blade.php ENDPATH**/ ?>