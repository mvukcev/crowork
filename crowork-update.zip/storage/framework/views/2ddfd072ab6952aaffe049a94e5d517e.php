<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Pricing <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> Simple plans for workers and employers using CroWork. <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container max-w-6xl">
            <p class="cw-kicker mb-3">Pricing</p>
            <h1 class="cw-display text-4xl md:text-6xl mb-4">Clear pricing for clear workflows.</h1>
            <p class="text-base text-slate-600 mb-8">Choose a plan based on hiring volume and support needs.</p>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <article class="cw-surface p-6">
                    <h2 class="text-xl font-semibold text-slate-900 mb-2">Starter</h2>
                    <p class="text-3xl font-semibold text-slate-900 mb-3">EUR 0</p>
                    <p class="text-slate-600 mb-4">For early exploration and pilot workflows.</p>
                    <a href="<?php echo e(url('/employer/register')); ?>" class="cw-button-secondary w-full" data-cw-track-click="employer_cta_click">Get started</a>
                </article>
                <article class="cw-surface p-6 border-amber-300">
                    <h2 class="text-xl font-semibold text-slate-900 mb-2">Growth</h2>
                    <p class="text-3xl font-semibold text-slate-900 mb-3">EUR 149/mo</p>
                    <p class="text-slate-600 mb-4">For active teams hiring across multiple roles.</p>
                    <a href="<?php echo e(url('/contact')); ?>" class="cw-button-accent w-full" data-cw-track-click="contact_submit">Talk to sales</a>
                </article>
                <article class="cw-surface p-6">
                    <h2 class="text-xl font-semibold text-slate-900 mb-2">Enterprise</h2>
                    <p class="text-3xl font-semibold text-slate-900 mb-3">Custom</p>
                    <p class="text-slate-600 mb-4">For high-volume recruitment and integrations.</p>
                    <a href="<?php echo e(url('/contact')); ?>" class="cw-button-secondary w-full" data-cw-track-click="contact_submit">Contact us</a>
                </article>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/pages/pricing.blade.php ENDPATH**/ ?>