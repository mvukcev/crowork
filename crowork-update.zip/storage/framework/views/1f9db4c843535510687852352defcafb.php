<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <?php
            $guestTitle = ($title ?? __('auth.page_title_default')).' - '.config('app.name', 'CroWork');
            $guestDescription = $description ?? __('seo.auth.access_description');
            $guestCanonical = $canonical ?? url()->current();
            $guestRobots = $robots ?? 'noindex,nofollow';
        ?>

        <title><?php echo e($guestTitle); ?></title>
        <meta name="description" content="<?php echo e($guestDescription); ?>">
        <meta name="robots" content="<?php echo e($guestRobots); ?>">
        <link rel="canonical" href="<?php echo e($guestCanonical); ?>">
        <meta property="og:title" content="<?php echo e($guestTitle); ?>">
        <meta property="og:description" content="<?php echo e($guestDescription); ?>">
        <meta property="og:type" content="website">
        <meta property="og:url" content="<?php echo e($guestCanonical); ?>">
        <meta property="og:image" content="<?php echo e(asset('assets/branding/CW-Logo-Dark.png')); ?>">
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($guestTitle); ?>">
        <meta name="twitter:description" content="<?php echo e($guestDescription); ?>">
        <meta name="twitter:image" content="<?php echo e(asset('assets/branding/CW-Logo-Dark.png')); ?>">
        <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/branding/CW-Favicon.svg')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/branding/CW-Favicon.png')); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(asset('assets/branding/CW-Favicon.png')); ?>">

        <?php if (isset($component)) { $__componentOriginalff3018920f514a2a3356c625e214876e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff3018920f514a2a3356c625e214876e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.theme-init','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('theme-init'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff3018920f514a2a3356c625e214876e)): ?>
<?php $attributes = $__attributesOriginalff3018920f514a2a3356c625e214876e; ?>
<?php unset($__attributesOriginalff3018920f514a2a3356c625e214876e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff3018920f514a2a3356c625e214876e)): ?>
<?php $component = $__componentOriginalff3018920f514a2a3356c625e214876e; ?>
<?php unset($__componentOriginalff3018920f514a2a3356c625e214876e); ?>
<?php endif; ?>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <!-- Analytics & Tracking -->
        <?php echo $__env->make('components.analytics-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php
            $queuedTrackEvents = session()->pull('cw_track_queue', []);
        ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(is_array($queuedTrackEvents) && count($queuedTrackEvents) > 0): ?>
            <script>
                window.__cwTrackQueue = <?php echo json_encode($queuedTrackEvents, 15, 512) ?>;
            </script>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </head>
    <?php
        $consentRequired = \App\Services\ConsentConfigService::isConsentRequired();
        $analyticsEnabled = \App\Services\AnalyticsConfigService::isAnalyticsEnabled();
        $marketingEnabled = \App\Services\MetaPixelConfigService::isTrackingEnabled();
        $trackDebug = app()->environment('local') || config('app.debug');
    ?>
    <body
        class="h-full cw-page overflow-x-hidden"
        data-cw-consent-required="<?php echo e($consentRequired ? '1' : '0'); ?>"
        data-cw-analytics-enabled="<?php echo e($analyticsEnabled ? '1' : '0'); ?>"
        data-cw-marketing-enabled="<?php echo e($marketingEnabled ? '1' : '0'); ?>"
        data-cw-track-debug="<?php echo e($trackDebug ? '1' : '0'); ?>"
    >
        <div class="min-h-screen flex flex-col cw-page-shell">
            <div class="cw-page-ambient cw-organic-bg" aria-hidden="true">
                <span class="cw-orb cw-orb-blue hidden md:block" style="width: 360px; height: 360px; left: -120px; top: 5rem;"></span>
                <span class="cw-orb cw-orb-orange hidden md:block" style="width: 300px; height: 300px; right: -90px; top: 12rem;"></span>
                <span class="cw-orb cw-orb-yellow hidden lg:block" style="width: 180px; height: 180px; right: 15%; bottom: 5rem;"></span>
            </div>
            <main class="flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8 cw-section-atmosphere">
                <span class="cw-corner-glow cw-orb-blue hidden lg:block" style="width: 360px; height: 360px; top: -110px; right: 14%;"></span>
                <span class="cw-corner-glow cw-orb-cyan hidden lg:block" style="width: 300px; height: 300px; bottom: -130px; left: 9%;"></span>

                <div class="cw-auth-shell mx-auto">
                    <aside class="cw-auth-aside hidden lg:block">
                        <div class="relative h-full">
                            <a href="<?php echo e(url('/')); ?>" class="inline-flex items-center gap-2 text-slate-900">
                                <img
                                    src="<?php echo e(asset('assets/branding/CW-Logo-Dark.svg')); ?>"
                                    alt="CroWork"
                                    class="h-6 w-auto cw-logo-on-light"
                                    onerror="this.style.display='none';"
                                >
                                <img
                                    src="<?php echo e(asset('assets/branding/CW-Logo-Light.svg')); ?>"
                                    alt="CroWork"
                                    class="h-6 w-auto cw-logo-on-dark"
                                    onerror="this.style.display='none'; this.nextElementSibling.style.display='inline';"
                                >
                                <span class="hidden text-base font-semibold">CroWork</span>
                            </a>
                            <p class="text-[2rem] leading-tight font-semibold text-slate-800 mt-12 max-w-[260px]"><?php echo e(__('auth.marketing_title')); ?></p>
                            <p class="text-sm text-slate-600 mt-4 max-w-[260px]"><?php echo e(__('auth.marketing_subtitle')); ?></p>

                            <div class="absolute inset-x-0 bottom-0 h-[240px] rounded-2xl bg-white/55 border border-white/70 overflow-hidden">
                                <span class="cw-orb cw-orb-violet" style="width: 180px; height: 180px; left: -40px; bottom: 14px;"></span>
                                <span class="cw-orb cw-orb-orange" style="width: 140px; height: 140px; right: -30px; top: 16px;"></span>
                                <span class="cw-orb cw-orb-yellow" style="width: 120px; height: 120px; right: 58px; bottom: -28px;"></span>
                            </div>
                        </div>
                    </aside>

                    <section class="cw-auth-main">
                        <div class="flex items-center justify-between mb-5 lg:hidden">
                            <a href="<?php echo e(url('/')); ?>" class="inline-flex items-center">
                                <img
                                    src="<?php echo e(asset('assets/branding/CW-Logo-Dark.svg')); ?>"
                                    alt="CroWork"
                                    class="h-5 w-auto cw-logo-on-light"
                                    onerror="this.style.display='none';"
                                >
                                <img
                                    src="<?php echo e(asset('assets/branding/CW-Logo-Light.svg')); ?>"
                                    alt="CroWork"
                                    class="h-5 w-auto cw-logo-on-dark"
                                    onerror="this.style.display='none'; this.nextElementSibling.style.display='inline';"
                                >
                                <span class="hidden text-[15px] font-semibold text-slate-900">CroWork</span>
                            </a>
                            <a href="<?php echo e(route('home')); ?>" class="text-sm text-slate-600 hover:text-slate-900"><?php echo e(__('auth.back_home')); ?></a>
                        </div>
                        <div class="max-w-[520px] mx-auto">
                            <?php echo e($slot); ?>

                        </div>
                    </section>
                </div>
            </main>

            <div class="cw-container pb-7 pt-2">
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-slate-600">
                    <p class="m-0"><?php echo e(__('footer.copyright', ['year' => date('Y')])); ?></p>
                    <div class="flex items-center gap-5">
                        <a href="<?php echo e(url('/about')); ?>" class="hover:text-slate-900 transition-colors"><?php echo e(__('navigation.about')); ?></a>
                        <a href="<?php echo e(url('/contact')); ?>" class="hover:text-slate-900 transition-colors"><?php echo e(__('auth.contact')); ?></a>
                        <a href="<?php echo e(url('/privacy')); ?>" class="hover:text-slate-900 transition-colors"><?php echo e(__('footer.privacy')); ?></a>
                        <a href="<?php echo e(url('/terms')); ?>" class="hover:text-slate-900 transition-colors"><?php echo e(__('footer.terms')); ?></a>
                    </div>
                </div>
            </div>

            <section class="cw-cookie-banner cw-soft-reveal" data-cw-cookie-banner hidden>
                <div class="cw-cookie-inner">
                    <p class="cw-cookie-text">
                        <?php echo __('footer.cookie.text', [
                            'link' => '<a href="' . route('cookies') . '" class="font-medium text-slate-900 underline">' . __('footer.cookie.link_label') . '</a>',
                        ]); ?>

                    </p>
                    <div class="cw-cookie-actions">
                        <button type="button" class="cw-button-secondary" data-cw-cookie-choice="required"><?php echo e(__('footer.cookie.required_only')); ?></button>
                        <button type="button" class="cw-button-primary" data-cw-cookie-choice="all"><?php echo e(__('footer.cookie.allow_all')); ?></button>
                    </div>
                </div>
            </section>
        </div>

        <?php echo $__env->make('components.analytics-noscript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>
</html>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/layouts/guest.blade.php ENDPATH**/ ?>