<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php
        $seoTitle = ($title ?? config('app.name', 'CroWork')).' - Find Your Career in Croatia';
        $seoDescription = $description ?? 'CroWork connects international talent with Croatian employers. Find jobs, education opportunities, and build your career in Croatia.';
        $canonicalUrl = trim($__env->yieldContent('canonical')) ?: ($canonical ?? url()->current());
        $ogTitle = $ogTitle ?? ($title ?? config('app.name', 'CroWork'));
        $ogDescription = $ogDescription ?? $seoDescription;
        $ogType = $ogType ?? 'website';
        $ogImage = $ogImage ?? asset('assets/branding/CW-Logo-Dark.png');
        $robots = $robots ?? 'index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1';
    ?>

    <title><?php echo e($seoTitle); ?></title>
    <meta name="description" content="<?php echo e($seoDescription); ?>">
    <meta name="robots" content="<?php echo e($robots); ?>">
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/branding/CW-Favicon.svg')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/branding/CW-Favicon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/branding/CW-Favicon.png')); ?>">
    <meta property="og:title" content="<?php echo e($ogTitle); ?>">
    <meta property="og:site_name" content="CroWork">
    <meta property="og:description" content="<?php echo e($ogDescription); ?>">
    <meta property="og:type" content="<?php echo e($ogType); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">
    <meta property="og:image" content="<?php echo e($ogImage); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($ogTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($ogDescription); ?>">
    <meta name="twitter:image" content="<?php echo e($ogImage); ?>">

    <?php if (isset($component)) { $__componentOriginalff3018920f514a2a3356c625e214876e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff3018920f514a2a3356c625e214876e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.theme-init','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('theme-init'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff3018920f514a2a3356c625e214876e)): ?>
<?php $attributes = $__attributesOriginalff3018920f514a2a3356c625e214876e; ?>
<?php unset($__attributesOriginalff3018920f514a2a3356c625e214876e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff3018920f514a2a3356c625e214876e)): ?>
<?php $component = $__componentOriginalff3018920f514a2a3356c625e214876e; ?>
<?php unset($__componentOriginalff3018920f514a2a3356c625e214876e); ?>
<?php endif; ?>

    

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Analytics & Tracking -->
    <?php echo $__env->make('components.analytics-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php
    $brandDisplayRoutes = [
        'home',
        'jobs.index',
        'jobs.show',
        'educations.index',
        'educations.show',
        'companies.show',
        'resources.index',
        'resources.show',
        'about',
        'for-employers',
        'pricing',
        'contact',
        'coming-soon',
    ];

    $useBrandDisplay = request()->routeIs($brandDisplayRoutes);
?>
<?php
    $consentRequired = \App\Services\ConsentConfigService::isConsentRequired();
    $analyticsEnabled = \App\Services\AnalyticsConfigService::isAnalyticsEnabled();
    $marketingEnabled = \App\Services\MetaPixelConfigService::isTrackingEnabled();
?>
<body class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'h-full cw-page' => true,
    'cw-brand-display' => $useBrandDisplay,
]); ?>"
data-cw-consent-required="<?php echo e($consentRequired ? '1' : '0'); ?>"
data-cw-analytics-enabled="<?php echo e($analyticsEnabled ? '1' : '0'); ?>"
data-cw-marketing-enabled="<?php echo e($marketingEnabled ? '1' : '0'); ?>"
x-data>
    <?php ($isHome = request()->routeIs('home')); ?>
    <?php ($isImpersonating = session('impersonation_original_admin_id')); ?>
    <div class="min-h-screen flex flex-col cw-page-shell">
    <div class="cw-page-ambient cw-organic-bg" aria-hidden="true">
        <span class="cw-orb cw-orb-blue hidden md:block" style="width: 420px; height: 420px; left: -140px; top: 5rem;"></span>
        <span class="cw-orb cw-orb-orange hidden md:block" style="width: 360px; height: 360px; right: -120px; top: 16rem;"></span>
        <span class="cw-orb cw-orb-yellow hidden lg:block" style="width: 240px; height: 240px; right: 18%; bottom: 8rem;"></span>
    </div>
    <?php if (isset($component)) { $__componentOriginalfdc8967a87956c0a7185abbef03fae20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdc8967a87956c0a7185abbef03fae20 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $attributes = $__attributesOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $component = $__componentOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__componentOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>
    <?php echo $__env->make('components.impersonation-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'flex-1' => true,
        'pt-0' => $isHome,
        'pt-16 md:pt-[72px]' => ! $isHome,
        'pt-28 md:pt-[124px]' => $isImpersonating,
    ]); ?>">
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="cw-container mt-6 mb-6">
                <div class="cw-surface p-4 border-emerald-200 bg-emerald-50" role="alert">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 text-emerald-700 flex-shrink-0 mt-0.5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p class="text-sm text-emerald-700"><?php echo e(session('success')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div class="cw-container mt-6 mb-6">
                <div class="cw-surface p-4 border-red-200 bg-red-50" role="alert">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 text-red-700 flex-shrink-0 mt-0.5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p class="text-sm text-red-700"><?php echo e(session('error')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('warning')): ?>
            <div class="cw-container mt-6 mb-6">
                <div class="cw-surface p-4 border-amber-200 bg-amber-50" role="alert">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <p class="text-sm text-amber-700"><?php echo e(session('warning')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('info')): ?>
            <div class="cw-container mt-6 mb-6">
                <div class="cw-surface p-4" role="alert">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 text-slate-600 flex-shrink-0 mt-0.5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p class="text-sm text-slate-600"><?php echo e(session('info')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div>
            <?php echo $__env->yieldContent('content', $slot ?? ''); ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="cw-footer mt-auto">
        <div class="cw-orb cw-orb-violet hidden md:block" style="width: 360px; height: 360px; right: -120px; bottom: -170px;"></div>
        <div class="cw-container py-8 md:py-10">
            <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-200">
                <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2.5">
                    <img
                        src="<?php echo e(asset('assets/branding/CW-Logo-Dark.svg')); ?>"
                        alt="CroWork"
                        class="h-7 w-auto cw-logo-on-light"
                        onerror="this.style.display='none';"
                    >
                    <img
                        src="<?php echo e(asset('assets/branding/CW-Logo-Light.svg')); ?>"
                        alt="CroWork"
                        class="h-7 w-auto cw-logo-on-dark"
                        onerror="this.style.display='none'; this.nextElementSibling.style.display='inline';"
                    >
                    <span class="hidden text-lg font-semibold text-slate-900">CroWork</span>
                    <div>
                        <p class="text-xs uppercase tracking-[0.08em] text-slate-500 mb-0"><?php echo e(__('footer.platform_label')); ?></p>
                    </div>
                </a>
                <div class="flex flex-wrap items-center gap-4 md:gap-5">
                    <a href="<?php echo e(route('jobs.index')); ?>" class="cw-footer-link" data-cw-track-click="navigation_click"><?php echo e(__('navigation.jobs')); ?></a>
                    <a href="<?php echo e(route('educations.index')); ?>" class="cw-footer-link" data-cw-track-click="navigation_click"><?php echo e(__('navigation.educations')); ?></a>
                    <a href="<?php echo e(route('resources.index')); ?>" class="cw-footer-link" data-cw-track-click="navigation_click"><?php echo e(__('navigation.resources')); ?></a>
                    <a href="<?php echo e(route('resources.show', 'work-permits')); ?>" class="cw-footer-link"><?php echo e(__('footer.work_permits')); ?></a>
                    <a href="<?php echo e(route('resources.show', 'faq-foreign-workers')); ?>" class="cw-footer-link"><?php echo e(__('footer.worker_faq')); ?></a>
                    <a href="<?php echo e(route('for-employers')); ?>" class="cw-footer-link" data-cw-track-click="navigation_click"><?php echo e(__('navigation.for_employers')); ?></a>
                    <a href="<?php echo e(route('about')); ?>" class="cw-footer-link" data-cw-track-click="navigation_click"><?php echo e(__('navigation.about')); ?></a>
                    <a href="<?php echo e(route('privacy')); ?>" class="cw-footer-link"><?php echo e(__('footer.privacy')); ?></a>
                    <a href="<?php echo e(route('terms')); ?>" class="cw-footer-link"><?php echo e(__('footer.terms')); ?></a>
                </div>
            </div>
            <div class="pt-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <p class="text-sm text-slate-500 mb-0"><?php echo e(__('footer.copyright', ['year' => date('Y')])); ?></p>
                <p class="text-xs uppercase tracking-[0.08em] text-slate-500 mb-0"><?php echo e(__('footer.slogan')); ?></p>
            </div>
        </div>
    </footer>

    <section class="cw-cookie-banner cw-soft-reveal" data-cw-cookie-banner hidden>
        <div class="cw-cookie-inner">
            <p class="cw-cookie-text">
                <?php echo __('footer.cookie.text', [
                    'link' => '<a href="' . route('cookies') . '" class="font-medium text-slate-900 underline">' . __('footer.cookie.link_label') . '</a>',
                ]); ?>

            </p>
            <div class="cw-cookie-actions">
                <button type="button" class="cw-button-secondary" data-cw-cookie-choice="required"><?php echo e(__('footer.cookie.required_only')); ?></button>
                <button type="button" class="cw-button-primary" data-cw-cookie-choice="all"><?php echo e(__('footer.cookie.allow_all')); ?></button>
            </div>
        </div>
    </section>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    <!-- Scroll Fade-In Animation -->
    <script>
        // Simple scroll-based fade-in animation
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            });

            // Observe all elements with scroll-fade-in class
            document.addEventListener('DOMContentLoaded', () => {
                document.querySelectorAll('.scroll-fade-in').forEach(el => {
                    observer.observe(el);
                });
            });
        } else {
            // Fallback for older browsers: just show everything
            document.addEventListener('DOMContentLoaded', () => {
                document.querySelectorAll('.scroll-fade-in').forEach(el => {
                    el.classList.add('visible');
                });
            });
        }
    </script>

    <?php echo $__env->make('components.analytics-noscript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/layouts/app.blade.php ENDPATH**/ ?>