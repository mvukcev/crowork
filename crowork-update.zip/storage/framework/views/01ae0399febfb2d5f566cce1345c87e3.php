<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Report Listing <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> Submit a report for unsafe or misleading content. <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container max-w-2xl">
            <div class="mb-6">
                <h1 class="cw-display text-4xl md:text-5xl mb-2">Report listing</h1>
                <p class="text-slate-600">Help us keep CroWork safe. Our moderation team reviews every report.</p>
            </div>

            <div class="cw-surface p-6 md:p-7">
                <div class="mb-5 p-4 rounded-xl bg-amber-50 border border-amber-200">
                    <p class="text-sm text-amber-800 mb-0"><strong>Reporting:</strong> <?php echo e($targetTitle); ?></p>
                </div>

                <form method="POST" action="<?php echo e(route('reports.store')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e($type); ?>">
                    <input type="hidden" name="id" value="<?php echo e($targetId); ?>">

                    <div>
                        <label for="reason" class="cw-label">Reason</label>
                        <select id="reason" name="reason" required class="cw-field">
                            <option value="">Select a reason</option>
                            <option value="spam" <?php if(old('reason') === 'spam'): echo 'selected'; endif; ?>>Spam</option>
                            <option value="scam" <?php if(old('reason') === 'scam'): echo 'selected'; endif; ?>>Scam / Fraud</option>
                            <option value="fake" <?php if(old('reason') === 'fake'): echo 'selected'; endif; ?>>Fake listing</option>
                            <option value="misleading" <?php if(old('reason') === 'misleading'): echo 'selected'; endif; ?>>Misleading information</option>
                            <option value="inappropriate" <?php if(old('reason') === 'inappropriate'): echo 'selected'; endif; ?>>Inappropriate content</option>
                            <option value="other" <?php if(old('reason') === 'other'): echo 'selected'; endif; ?>>Other</option>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div>
                        <label for="message" class="cw-label">Additional details (optional)</label>
                        <textarea id="message" name="message" rows="5" maxlength="2000" class="cw-field" placeholder="Share details to help our moderation team."><?php echo e(old('message')); ?></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="flex flex-col sm:flex-row gap-2">
                        <button type="submit" class="cw-button-primary">Submit report</button>
                        <a href="<?php echo e(url()->previous()); ?>" class="cw-button-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/reports/create.blade.php ENDPATH**/ ?>