<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('worker.application_pages.jobs.page_title')); ?> <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-6">
                <div>
                    <p class="cw-kicker mb-1"><?php echo e(__('worker.application_pages.kicker')); ?></p>
                    <h1 class="cw-display text-4xl md:text-6xl"><?php echo e(__('worker.application_pages.jobs.title')); ?></h1>
                </div>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('worker.education-applications.index')); ?>" class="cw-button-secondary"><?php echo e(__('worker.application_pages.jobs.education_link')); ?></a>
                    <a href="<?php echo e(route('worker.settings.edit')); ?>" class="cw-button-secondary"><?php echo e(__('worker.application_pages.common.settings')); ?></a>
                </div>
            </div>

            <div class="cw-surface overflow-hidden">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($applications->count() > 0): ?>
                    <div class="overflow-x-auto">
                    <table class="cw-table min-w-[860px]">
                        <thead>
                            <tr>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.job')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.employer')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.status')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.applied')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.status_updated')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.motivation')); ?></th>
                                <th><?php echo e(__('worker.application_pages.jobs.columns.snapshot')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($application->job?->title ?? 'N/A'); ?></td>
                                    <td><?php echo e($application->job?->employer?->company_name ?? 'N/A'); ?></td>
                                    <td><?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['tone' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'info']); ?><?php echo e(__('applications.' . $application->status)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?></td>
                                    <td><?php echo e($application->created_at?->translatedFormat('d.m.Y.')); ?></td>
                                    <td><?php echo e($application->status_updated_at?->translatedFormat('d.m.Y. H:i') ?? 'N/A'); ?></td>
                                    <td class="max-w-xs">
                                        <p class="text-sm text-slate-700 line-clamp-2"><?php echo e($application->message ?: __('worker.application_pages.common.no_message')); ?></p>
                                    </td>
                                    <td><?php echo e(!empty($application->profile_snapshot) ? __('worker.application_pages.common.stored') : 'N/A'); ?></td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($application->job): ?>
                                            <a href="<?php echo e(route('jobs.show', $application->job)); ?>" class="cw-button-secondary"><?php echo e(__('worker.application_pages.common.view')); ?></a>
                                        <?php else: ?>
                                            <span class="text-xs text-slate-500"><?php echo e(__('worker.application_pages.common.unavailable')); ?></span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                    <div class="p-4"><?php echo e($applications->links()); ?></div>
                <?php else: ?>
                    <div class="p-6 md:p-8">
                        <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => 'inbox','title' => __('worker.application_pages.jobs.empty.title'),'description' => __('worker.application_pages.jobs.empty.body'),'actionHref' => route('jobs.index'),'actionLabel' => __('worker.application_pages.jobs.empty.browse')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'inbox','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('worker.application_pages.jobs.empty.title')),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('worker.application_pages.jobs.empty.body')),'actionHref' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('jobs.index')),'actionLabel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('worker.application_pages.jobs.empty.browse'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
                        <p class="text-sm text-slate-500 mt-4 text-center"><?php echo e(__('worker.application_pages.jobs.empty.note')); ?></p>
                        <div class="mt-4 flex justify-center">
                            <a href="<?php echo e(route('worker.profile.edit')); ?>" class="cw-button-secondary"><?php echo e(__('worker.application_pages.jobs.empty.complete_profile')); ?></a>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/worker/applications/jobs.blade.php ENDPATH**/ ?>