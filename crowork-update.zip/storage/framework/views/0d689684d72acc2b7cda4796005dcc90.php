<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Page Not Found <?php $__env->endSlot(); ?>
     <?php $__env->slot('robots', null, []); ?> noindex,follow <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container max-w-3xl text-center">
            <p class="cw-kicker mb-2">Error 404</p>
            <h1 class="cw-display text-5xl md:text-7xl mb-4">This page does not exist.</h1>
            <p class="text-base text-slate-600 mb-7">The link may be outdated or the page was moved.</p>
            <div class="flex flex-wrap justify-center gap-2">
                <a href="<?php echo e(route('home')); ?>" class="cw-button-primary">Go home</a>
                <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-secondary">Browse jobs</a>
                <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-secondary">Browse educations</a>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/errors/404.blade.php ENDPATH**/ ?>