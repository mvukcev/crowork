<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('about.seo.title')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(__('about.seo.description')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('about')); ?> <?php $__env->endSlot(); ?>

    <?php $__env->startPush('head'); ?>
        <script type="application/ld+json"><?php echo json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'AboutPage',
            'name' => __('about.seo.title'),
            'description' => __('about.seo.description'),
            'url' => route('about'),
            'inLanguage' => app()->getLocale(),
            'about' => [
                '@type' => 'Organization',
                'name' => config('app.name', 'CroWork'),
                'url' => route('home'),
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
        <script type="application/ld+json"><?php echo json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => __('ui.navigation.home'),
                    'item' => route('home'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => __('ui.navigation.about'),
                    'item' => route('about'),
                ],
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
    <?php $__env->stopPush(); ?>

    <section class="cw-section relative overflow-hidden">
        <div class="cw-container">
            <div class="about-hero-frame relative overflow-hidden rounded-3xl border border-white/50 shadow-[0_20px_70px_rgba(15,23,42,0.12)]">
                <img src="<?php echo e(asset('assets/about/hero/about-hero-1600x900.jpg')); ?>" alt="CroWork about hero" class="about-hero-image absolute inset-0 h-full w-full object-cover" />
                <div class="absolute inset-0 bg-[radial-gradient(circle_at_20%_15%,rgba(59,130,246,0.32),transparent_52%),radial-gradient(circle_at_75%_70%,rgba(124,58,237,0.30),transparent_48%),linear-gradient(180deg,rgba(2,6,23,0.56),rgba(2,6,23,0.78))]"></div>

                <div class="relative z-10 px-6 py-12 md:px-10 md:py-16 lg:px-14 lg:py-20">
                    <p class="cw-kicker text-white/80 mb-3"><?php echo e(__('about.hero.eyebrow')); ?></p>
                    <h1 class="cw-display text-3xl md:text-5xl max-w-4xl" style="color:#ffffff;"><?php echo __('about.hero.headline_html', [
                        'highlight_1' => '<span class="about-h1-highlight">' . __('about.hero.headline_highlight_1') . '</span>',
                        'highlight_2' => '<span class="about-h1-highlight">' . __('about.hero.headline_highlight_2') . '</span>',
                    ]); ?></h1>
                    <p class="mt-5 text-base md:text-lg max-w-3xl" style="color:rgba(255,255,255,0.92);"><?php echo e(__('about.hero.supporting')); ?></p>

                    <div class="mt-8 flex flex-wrap gap-3">
                        <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-accent"><?php echo e(__('about.hero.cta_jobs')); ?></a>
                        <a href="<?php echo e(route('for-employers')); ?>" class="cw-button-secondary about-hero-secondary-cta bg-white/10 border-white/30 text-white hover:bg-white/20"><?php echo e(__('about.hero.cta_employers')); ?></a>
                    </div>

                    <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-3 max-w-3xl">
                        <article class="rounded-2xl bg-white/15 backdrop-blur border border-white/20 p-4">
                            <h2 class="text-base font-semibold text-white"><?php echo e(__('about.hero.card_1_title')); ?></h2>
                            <p class="about-hero-card-text mt-1 text-sm"><?php echo e(__('about.hero.card_1_text')); ?></p>
                        </article>
                        <article class="rounded-2xl bg-white/15 backdrop-blur border border-white/20 p-4">
                            <h2 class="text-base font-semibold text-white"><?php echo e(__('about.hero.card_2_title')); ?></h2>
                            <p class="about-hero-card-text mt-1 text-sm"><?php echo e(__('about.hero.card_2_text')); ?></p>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cw-section">
        <div class="cw-container">
            <div class="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_420px] gap-8 items-start">
                <article class="cw-surface p-7 md:p-9 rounded-3xl">
                    <h2 class="cw-display text-3xl md:text-5xl"><?php echo e(__('about.why.headline')); ?></h2>
                    <p class="mt-4 text-slate-700 leading-relaxed"><?php echo e(__('about.why.body_1')); ?></p>
                    <p class="mt-4 text-slate-700 leading-relaxed"><?php echo e(__('about.why.body_2')); ?></p>
                    <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.why.points'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-700"><?php echo e($point); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </article>
                <aside class="about-visual-frame relative overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                    <img src="<?php echo e(asset('assets/about/philosophy/about-philosophy-1200x900.jpg')); ?>" alt="CroWork philosophy" class="about-visual-image w-full h-full object-cover" />
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-900/55 via-slate-900/20 to-transparent"></div>
                </aside>
            </div>
        </div>
    </section>

    <section class="cw-section">
        <div class="cw-container">
            <h2 class="cw-display text-3xl md:text-5xl mb-6"><?php echo e(__('about.what.headline')); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.what.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="about-what-card group relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-5 shadow-[0_12px_28px_rgba(15,23,42,0.06)] hover:-translate-y-1 hover:shadow-[0_20px_42px_rgba(15,23,42,0.10)] transition">
                        <div class="absolute -top-10 -right-10 h-28 w-28 rounded-full bg-gradient-to-br from-violet-200/50 to-sky-200/40 blur-2xl"></div>
                        <h3 class="text-xl font-semibold text-slate-900 relative"><?php echo e($item['title']); ?></h3>
                        <p class="mt-3 text-slate-600 leading-relaxed relative"><?php echo e($item['text']); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </section>

    <section class="cw-section">
        <div class="cw-container">
            <h2 class="cw-display text-3xl md:text-5xl mb-6"><?php echo e(__('about.audience.headline')); ?></h2>
            <div class="grid grid-cols-1 lg:grid-cols-[1fr_1.1fr] gap-6">
                <article class="about-audience-card rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm">
                    <div class="about-audience-row">
                        <div class="about-audience-main">
                            <h3 class="text-2xl font-semibold text-violet-700"><?php echo e(__('about.audience.workers_title')); ?></h3>
                            <div class="mt-5 space-y-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.audience.workers_points'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="text-slate-700"><?php echo e($point); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div class="about-audience-media">
                            <img src="<?php echo e(asset('assets/about/workers/about-workers-1200x900.jpg')); ?>" alt="Workers" class="h-full w-full object-cover" />
                        </div>
                    </div>
                </article>

                <article class="about-audience-card rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm">
                    <div class="about-audience-row">
                        <div class="about-audience-main">
                            <h3 class="text-2xl font-semibold text-sky-700"><?php echo e(__('about.audience.employers_title')); ?></h3>
                            <div class="mt-5 space-y-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.audience.employers_points'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="text-slate-700"><?php echo e($point); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div class="about-audience-media">
                            <img src="<?php echo e(asset('assets/about/employers/about-employers-1200x900.jpg')); ?>" alt="Employers" class="h-full w-full object-cover" />
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="cw-section">
        <div class="cw-container">
            <div class="cw-surface rounded-3xl p-6 md:p-10">
                <h2 class="cw-display text-3xl md:text-5xl"><?php echo e(__('about.approach.headline')); ?></h2>
                <p class="mt-3 text-slate-600 max-w-3xl"><?php echo e(__('about.approach.subtitle')); ?></p>
                <div class="mt-7 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.approach.principles'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $principle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="rounded-2xl border border-slate-200 bg-white p-4">
                            <p class="text-xs font-semibold uppercase tracking-[0.08em] text-violet-600"><?php echo e(str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT)); ?></p>
                            <h3 class="mt-1 text-lg font-semibold text-slate-900"><?php echo e($principle['title']); ?></h3>
                            <p class="mt-2 text-slate-600"><?php echo e($principle['text']); ?></p>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="cw-section">
        <div class="cw-container">
            <div class="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-6 items-stretch">
                <article class="about-visual-frame relative overflow-hidden rounded-3xl border border-slate-200 shadow-sm">
                    <img src="<?php echo e(asset('assets/about/future/about-future-1600x900.jpg')); ?>" alt="Future of work in Croatia" class="about-visual-image h-full w-full object-cover" />
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 via-slate-900/25 to-transparent"></div>
                    <div class="absolute bottom-0 p-6 md:p-8">
                        <h2 class="cw-display text-3xl md:text-4xl" style="color:#ffffff;"><?php echo e(__('about.future.headline')); ?></h2>
                        <p class="mt-3 text-white/90 max-w-2xl"><?php echo e(__('about.future.body')); ?></p>
                    </div>
                </article>

                <article class="cw-surface rounded-3xl p-6 md:p-8">
                    <h2 class="cw-display text-3xl md:text-4xl"><?php echo e(__('about.platform.headline')); ?></h2>
                    <p class="mt-3 text-slate-600"><?php echo e(__('about.platform.subtitle')); ?></p>
                    <div class="mt-6 space-y-5">
                        <div>
                            <h3 class="text-lg font-semibold text-slate-900"><?php echo e(__('about.platform.dash_title')); ?></h3>
                            <p class="text-slate-600"><?php echo e(__('about.platform.dash_text')); ?></p>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-slate-900"><?php echo e(__('about.platform.jobs_title')); ?></h3>
                            <p class="text-slate-600"><?php echo e(__('about.platform.jobs_text')); ?></p>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-slate-900"><?php echo e(__('about.platform.onboarding_title')); ?></h3>
                            <p class="text-slate-600"><?php echo e(__('about.platform.onboarding_text')); ?></p>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="cw-section pt-4">
        <div class="cw-container">
            <div class="cw-surface rounded-3xl p-6 md:p-8">
                <h2 class="cw-display text-3xl md:text-4xl"><?php echo e(__('about.trust.headline')); ?></h2>
                <div class="mt-5 grid grid-cols-1 md:grid-cols-2 gap-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = __('about.trust.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="rounded-xl border border-slate-200 bg-white p-4 text-slate-700"><?php echo e($item); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="cw-section pt-0">
        <div class="cw-container">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <img src="<?php echo e(asset('assets/about/platform/platform-dashboard-1400x900.jpg')); ?>" alt="Platform dashboard" class="about-bottom-image w-full rounded-2xl object-cover" />
                <img src="<?php echo e(asset('assets/about/platform/platform-jobs-1400x900.jpg')); ?>" alt="Platform jobs" class="about-bottom-image w-full rounded-2xl object-cover" />
                <img src="<?php echo e(asset('assets/about/platform/platform-onboarding-1400x900.jpg')); ?>" alt="Platform onboarding" class="about-bottom-image w-full rounded-2xl object-cover" />
            </div>
        </div>
    </section>

    <?php $__env->startPush('styles'); ?>
        <style>
            .about-hero-frame,
            .about-visual-frame,
            .about-hero-image,
            .about-visual-image {
                border-radius: 1.5rem !important;
            }

            .about-hero-frame,
            .about-visual-frame {
                overflow: hidden;
            }

            .about-hero-card-text {
                color: rgba(255, 255, 255, 0.9) !important;
            }

            .about-h1-highlight {
                color: #6d28d9;
            }

            .about-bottom-image {
                height: 16.5rem !important;
            }

            .about-what-card,
            .about-audience-card {
                border-radius: 1.5rem !important;
            }

            .about-audience-row {
                display: flex;
                flex-direction: column;
                gap: 1.25rem;
            }

            .about-audience-main {
                flex: 1 1 auto;
            }

            .about-audience-media {
                width: 100%;
                height: 220px;
                overflow: hidden;
                border-radius: 1rem;
            }

            @media (min-width: 768px) {
                .about-audience-row {
                    flex-direction: row;
                    align-items: stretch;
                }

                .about-audience-media {
                    width: 16rem;
                    flex: 0 0 16rem;
                    height: auto;
                }

                .about-bottom-image {
                    height: 17rem !important;
                }
            }
        </style>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/pages/about.blade.php ENDPATH**/ ?>