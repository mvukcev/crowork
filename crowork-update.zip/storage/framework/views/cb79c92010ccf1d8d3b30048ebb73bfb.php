<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> About CroWork <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> Learn how CroWork connects workers, employers, and education providers in Croatia. <?php $__env->endSlot(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="cw-content-wide">
            <p class="cw-kicker mb-3">About</p>
            <h1 class="cw-display text-3xl md:text-5xl mb-4">A clearer migration experience for everyone involved.</h1>
            <p class="text-base text-slate-600 leading-relaxed cw-measure-md">CroWork is built to remove uncertainty from international hiring and relocation workflows by connecting jobs, readiness, and education in one system.</p>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-10">
                <article class="cw-surface p-5"><h2 class="text-lg font-semibold text-slate-900 mb-2">Workers</h2><p class="text-slate-600">Track progress and expectations in one place.</p></article>
                <article class="cw-surface p-5"><h2 class="text-lg font-semibold text-slate-900 mb-2">Employers</h2><p class="text-slate-600">Keep hiring pipelines structured and transparent.</p></article>
                <article class="cw-surface p-5"><h2 class="text-lg font-semibold text-slate-900 mb-2">Educators</h2><p class="text-slate-600">Align skills training with live role demand.</p></article>
            </div>

            <div class="mt-8">
                <a href="<?php echo e(route('contact')); ?>" class="cw-button-primary" data-cw-track-click="contact_submit">Contact us</a>
            </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/pages/about.blade.php ENDPATH**/ ?>