<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jobs->count() > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalbb7abfc421304865208a8164802344c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb7abfc421304865208a8164802344c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.job-card','data' => ['title' => $job->title,'company' => $job->employer?->company_name,'companyHref' => $job->employer?->slug ? route('companies.show', $job->employer) : null,'city' => $job->location_city,'salaryMin' => $job->salary_min,'salaryMax' => $job->salary_max,'salaryCurrency' => $job->salary_currency ?? 'EUR','salaryPeriod' => $job->salary_period ?? 'month','employmentType' => $job->contract_type,'experienceLevel' => $job->experience_level,'educationRequired' => $job->education_required,'positionsAvailable' => $job->positions_available,'workingHours' => $job->working_hours,'startDate' => $job->start_date,'startFlexibility' => $job->start_flexibility,'accommodationProvided' => $job->accommodation_provided,'visaSupport' => $job->visa_support,'isUrgent' => $job->is_urgent,'isFeatured' => $job->is_featured,'languages' => $job->languages ?? [],'postedAt' => $job->published_at ?? $job->created_at,'href' => route('jobs.show', $job)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('job-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->title),'company' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->employer?->company_name),'company_href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->employer?->slug ? route('companies.show', $job->employer) : null),'city' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->location_city),'salary_min' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_min),'salary_max' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_max),'salary_currency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_currency ?? 'EUR'),'salary_period' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_period ?? 'month'),'employment_type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->contract_type),'experience_level' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->experience_level),'education_required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->education_required),'positions_available' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->positions_available),'working_hours' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->working_hours),'start_date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->start_date),'start_flexibility' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->start_flexibility),'accommodation_provided' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->accommodation_provided),'visa_support' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->visa_support),'is_urgent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->is_urgent),'is_featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->is_featured),'languages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->languages ?? []),'posted_at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->published_at ?? $job->created_at),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('jobs.show', $job))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb7abfc421304865208a8164802344c3)): ?>
<?php $attributes = $__attributesOriginalbb7abfc421304865208a8164802344c3; ?>
<?php unset($__attributesOriginalbb7abfc421304865208a8164802344c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb7abfc421304865208a8164802344c3)): ?>
<?php $component = $__componentOriginalbb7abfc421304865208a8164802344c3; ?>
<?php unset($__componentOriginalbb7abfc421304865208a8164802344c3); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="mt-6">
        <?php echo e($jobs->links()); ?>

    </div>
<?php else: ?>
    <div class="cw-surface p-12 text-center rounded-2xl border-2 border-dashed border-slate-200">
        <svg class="mx-auto h-12 w-12 text-slate-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
        </svg>
        <h3 class="text-xl font-semibold text-slate-900 mb-2"><?php echo e(__('ui.jobs_page.no_results_heading')); ?></h3>
        <p class="text-slate-600 mb-6"><?php echo e(__('ui.jobs_page.no_results_description')); ?></p>
        <div class="flex flex-wrap gap-3 justify-center">
            <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-secondary"><?php echo e(__('ui.jobs_page.no_results_clear')); ?></a>
            <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-primary"><?php echo e(__('ui.jobs_page.no_results_browse')); ?></a>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/jobs/_results.blade.php ENDPATH**/ ?>