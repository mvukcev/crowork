<?php
    $profile = $worker->workerProfile;
    $languages = is_array($profile?->languages ?? null) ? $profile->languages : [];
    $skills = is_array($profile?->skills ?? null) ? $profile->skills : [];
    $desiredRoles = is_array($profile?->desired_roles ?? null) ? $profile->desired_roles : [];
?>

<div class="space-y-5">
    <div class="flex items-start justify-between gap-4">
        <div>
            <p class="text-xs uppercase tracking-[0.08em] text-slate-500">Worker CV Preview</p>
            <h3 class="mt-1 text-lg font-semibold text-slate-900"><?php echo e($worker->name); ?></h3>
            <p class="text-sm text-slate-600"><?php echo e($worker->email); ?></p>
        </div>
        <div class="text-right text-sm text-slate-600">
            <p>Applications: <?php echo e($worker->applications_count); ?></p>
            <p>Education applications: <?php echo e($worker->education_applications_count); ?></p>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $profile): ?>
        <div class="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
            This worker does not have a profile yet.
        </div>
    <?php else: ?>
        <div class="rounded-xl border border-slate-200 bg-white p-4 space-y-4">
            <div class="grid gap-3 md:grid-cols-2 text-sm">
                <p><strong>Completeness:</strong> <?php echo e($profile->completenessPercent()); ?>%</p>
                <p><strong>Visibility:</strong> <?php echo e(\App\Models\WorkerProfile::visibilityOptions()[$profile->profile_visibility] ?? 'N/A'); ?></p>
                <p><strong>Current location:</strong> <?php echo e(trim(($profile->current_city ?? '') . ', ' . ($profile->current_country ?? ''), ', ') ?: 'N/A'); ?></p>
                <p><strong>Desired city:</strong> <?php echo e($profile->desired_city ?: 'N/A'); ?></p>
                <p><strong>Availability:</strong> <?php echo e($profile->availability_date?->format('M j, Y') ?: 'N/A'); ?></p>
                <p><strong>Communication language:</strong> <?php echo e($profile->communication_language ?: $worker->communication_language ?: 'N/A'); ?></p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile->professional_summary): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Professional summary</h4>
                    <p class="text-sm text-slate-700 whitespace-pre-line"><?php echo e($profile->professional_summary); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile->education_summary): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Education summary</h4>
                    <p class="text-sm text-slate-700 whitespace-pre-line"><?php echo e($profile->education_summary); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile->work_experience): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Work experience</h4>
                    <p class="text-sm text-slate-700 whitespace-pre-line"><?php echo e($profile->work_experience); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($skills !== []): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Skills</h4>
                    <div class="flex flex-wrap gap-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="rounded-full border border-slate-200 px-2.5 py-1 text-xs text-slate-700"><?php echo e($skill); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($languages !== []): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Languages</h4>
                    <ul class="space-y-1 text-sm text-slate-700">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $languageName = is_array($language) ? trim((string) ($language['language'] ?? '')) : trim((string) $language);
                                $languageLevel = is_array($language) ? trim((string) ($language['level'] ?? '')) : '';
                            ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($languageName !== ''): ?>
                                <li><?php echo e($languageName); ?><?php echo e($languageLevel !== '' ? ' (' . $languageLevel . ')' : ''); ?></li>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($desiredRoles !== []): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Desired roles</h4>
                    <div class="flex flex-wrap gap-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $desiredRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="rounded-full border border-slate-200 px-2.5 py-1 text-xs text-slate-700"><?php echo e($role); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile->recommendations): ?>
                <div>
                    <h4 class="text-sm font-semibold text-slate-900 mb-1">Recommendations</h4>
                    <p class="text-sm text-slate-700 whitespace-pre-line"><?php echo e($profile->recommendations); ?></p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/filament/admin/worker-profile-preview.blade.php ENDPATH**/ ?>