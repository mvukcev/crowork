<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($educations->count() > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $provider = $education->createdByUser?->employer?->company_name ?? $education->createdByUser?->name;
            ?>
            <?php if (isset($component)) { $__componentOriginal85e1a52f5c308572979b8e1f0108fa9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal85e1a52f5c308572979b8e1f0108fa9f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.education-card','data' => ['title' => $education->title,'provider' => $provider,'city' => $education->city,'isOnline' => $education->is_online,'startDate' => $education->start_date,'priceCents' => $education->price_cents,'currency' => $education->currency ?? 'EUR','postedAt' => $education->published_at ?? $education->created_at,'href' => route('educations.show', $education)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('education-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->title),'provider' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($provider),'city' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->city),'is_online' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->is_online),'start_date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->start_date),'price_cents' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->price_cents),'currency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->currency ?? 'EUR'),'posted_at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($education->published_at ?? $education->created_at),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('educations.show', $education))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal85e1a52f5c308572979b8e1f0108fa9f)): ?>
<?php $attributes = $__attributesOriginal85e1a52f5c308572979b8e1f0108fa9f; ?>
<?php unset($__attributesOriginal85e1a52f5c308572979b8e1f0108fa9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85e1a52f5c308572979b8e1f0108fa9f)): ?>
<?php $component = $__componentOriginal85e1a52f5c308572979b8e1f0108fa9f; ?>
<?php unset($__componentOriginal85e1a52f5c308572979b8e1f0108fa9f); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="mt-6">
        <?php echo e($educations->links()); ?>

    </div>
<?php else: ?>
    <div class="cw-surface p-10 text-center rounded-2xl border-2 border-dashed border-slate-200">
        <h3 class="text-xl font-semibold text-slate-900 mb-2"><?php echo e(__('ui.educations_page.no_results_heading')); ?></h3>
        <p class="text-slate-600 mb-5"><?php echo e(__('ui.educations_page.no_results_description')); ?></p>
        <div class="flex flex-wrap justify-center gap-2">
            <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-secondary"><?php echo e(__('ui.educations_page.no_results_clear')); ?></a>
            <a href="<?php echo e(route('educations.index')); ?>" class="cw-button-primary"><?php echo e(__('ui.educations_page.no_results_browse')); ?></a>
        </div>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/educations/_results.blade.php ENDPATH**/ ?>