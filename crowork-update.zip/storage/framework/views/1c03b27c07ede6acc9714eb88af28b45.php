<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($education->title); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(\Illuminate\Support\Str::limit(strip_tags($education->description), 150)); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('educations.show', $education)); ?> <?php $__env->endSlot(); ?>

    <?php
        $breadcrumbSchema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => route('home'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Educations',
                    'item' => route('educations.index'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $education->title,
                    'item' => route('educations.show', $education),
                ],
            ],
        ];
    ?>

    <?php $__env->startPush('head'); ?>
        <script type="application/ld+json"><?php echo json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
    <?php $__env->stopPush(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="mb-6 text-sm text-slate-500">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-slate-900">Home</a>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('educations.index')); ?>" class="hover:text-slate-900">Educations</a>
                <span class="mx-1">/</span>
                <span class="text-slate-700"><?php echo e($education->title); ?></span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <article class="lg:col-span-2 cw-surface p-6 md:p-7">
                    <p class="text-xs text-slate-500 mb-1"><?php echo e($provider ?? ($education->createdByUser?->name ?? 'Education provider')); ?></p>
                    <h1 class="cw-display text-4xl md:text-6xl mb-3"><?php echo e($education->title); ?></h1>
                    <p class="text-sm text-slate-500 mb-4">Posted <?php echo e($postedDisplay ?? ($education->published_at?->diffForHumans() ?? $education->created_at?->diffForHumans())); ?></p>
                    <div class="prose max-w-none text-slate-700 leading-relaxed"><?php echo nl2br(e($education->description)); ?></div>
                </article>

                <aside class="cw-surface p-5">
                    <h2 class="text-lg font-semibold text-slate-900 mb-3">Program details</h2>
                    <p class="text-sm text-slate-700 mb-2"><strong>Location:</strong> <?php echo e($locationDisplay ?? ($education->is_online ? 'Online' : ($education->city ?: 'Croatia'))); ?></p>
                    <p class="text-sm text-slate-700 mb-2"><strong>Price:</strong> <?php echo e($priceDisplay ?? (($education->currency ?? 'EUR') . ' ' . number_format(($education->price_cents ?? 0) / 100, 2))); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($education->start_date): ?>
                        <p class="text-sm text-slate-700 mb-2"><strong>Start:</strong> <?php echo e($startDateDisplay ?? $education->start_date->format('M j, Y')); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($education->capacity): ?>
                        <p class="text-sm text-slate-700 mb-2"><strong>Capacity:</strong> <?php echo e($education->capacity); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <a href="<?php echo e(route('educations.apply', $education)); ?>" class="cw-button-primary w-full mt-3" data-cw-track-click="apply_start">Apply now</a>
                </aside>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('education_view', {
                    education_slug: <?php echo json_encode($education->slug, 15, 512) ?>,
                    provider: <?php echo json_encode($provider ?? ($education->createdByUser?->name ?? null), 15, 512) ?>
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/educations/show.blade.php ENDPATH**/ ?>