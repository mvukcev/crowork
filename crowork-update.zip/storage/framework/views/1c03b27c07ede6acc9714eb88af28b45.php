<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($education->title); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(\Illuminate\Support\Str::limit(strip_tags($education->description), 150)); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('educations.show', $education)); ?> <?php $__env->endSlot(); ?>

    <?php
        $providerName = $provider ?? ($education->createdByUser?->name ?? __('ui.educations_show.provider_fallback'));
        $locationValue = $locationDisplay ?? ($education->is_online ? __('ui.educations_show.online') : ($education->city ?: __('ui.educations_show.default_country')));
        $priceValue = (int) ($education->price_cents ?? 0);

        $educationSchema = [
            '@context' => 'https://schema.org',
            '@type' => $priceValue > 0 ? 'Course' : 'EducationalOccupationalProgram',
            'name' => $education->title,
            'description' => \Illuminate\Support\Str::limit(strip_tags((string) $education->description), 3000, ''),
            'provider' => [
                '@type' => 'Organization',
                'name' => $providerName,
            ],
            'url' => route('educations.show', $education),
            'inLanguage' => app()->getLocale(),
            'courseMode' => $education->is_online ? 'online' : 'onsite',
            'location' => $education->is_online ? null : [
                '@type' => 'Place',
                'address' => [
                    '@type' => 'PostalAddress',
                    'addressLocality' => $education->city,
                    'addressCountry' => 'HR',
                ],
            ],
            'offers' => $priceValue > 0 ? [
                '@type' => 'Offer',
                'price' => number_format($priceValue / 100, 2, '.', ''),
                'priceCurrency' => strtoupper((string) ($education->currency ?? 'EUR')),
                'availability' => 'https://schema.org/InStock',
                'url' => route('educations.show', $education),
            ] : null,
        ];

        $educationSchema = array_filter($educationSchema, fn ($value) => ! is_null($value) && $value !== '');

        $breadcrumbSchema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => __('ui.navigation.home'),
                    'item' => route('home'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => __('ui.navigation.educations'),
                    'item' => route('educations.index'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $education->title,
                    'item' => route('educations.show', $education),
                ],
            ],
        ];
    ?>

    <?php $__env->startPush('head'); ?>
        <script type="application/ld+json"><?php echo json_encode($educationSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
        <script type="application/ld+json"><?php echo json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
    <?php $__env->stopPush(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="mb-6 text-sm text-slate-500">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-slate-900"><?php echo e(__('ui.navigation.home')); ?></a>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('educations.index')); ?>" class="hover:text-slate-900"><?php echo e(__('ui.navigation.educations')); ?></a>
                <span class="mx-1">/</span>
                <span class="text-slate-700"><?php echo e($education->title); ?></span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <article class="lg:col-span-2 cw-surface p-6 md:p-7">
                    <p class="text-xs text-slate-500 mb-1"><?php echo e($providerName); ?></p>
                    <h1 class="cw-display text-4xl md:text-6xl mb-3"><?php echo e($education->title); ?></h1>
                    <p class="text-sm text-slate-500 mb-4"><?php echo e(__('ui.educations_show.posted_prefix')); ?> <?php echo e($postedDisplay ?? ($education->published_at?->diffForHumans() ?? $education->created_at?->diffForHumans())); ?></p>
                    <div class="prose max-w-none text-slate-700 leading-relaxed"><?php echo nl2br(e($education->description)); ?></div>
                </article>

                <aside class="cw-surface p-5">
                    <h2 class="text-lg font-semibold text-slate-900 mb-3"><?php echo e(__('ui.educations_show.details_heading')); ?></h2>
                    <p class="text-sm text-slate-700 mb-2"><strong><?php echo e(__('ui.educations_show.location_label')); ?></strong> <?php echo e($locationValue); ?></p>
                    <p class="text-sm text-slate-700 mb-2"><strong><?php echo e(__('ui.educations_show.price_label')); ?></strong> <?php echo e($priceDisplay ?? (($education->currency ?? 'EUR') . ' ' . number_format(($education->price_cents ?? 0) / 100, 2))); ?></p>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($education->start_date): ?>
                        <p class="text-sm text-slate-700 mb-2"><strong><?php echo e(__('ui.educations_show.start_label')); ?></strong> <?php echo e($startDateDisplay ?? $education->start_date->translatedFormat('j M Y')); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($education->capacity): ?>
                        <p class="text-sm text-slate-700 mb-2"><strong><?php echo e(__('ui.educations_show.capacity_label')); ?></strong> <?php echo e($education->capacity); ?></p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <a href="<?php echo e(route('educations.apply', $education)); ?>" class="cw-button-primary w-full mt-3" data-cw-track-click="education_apply_click" data-cw-item-type="education" data-cw-item-slug="<?php echo e($education->slug); ?>"><?php echo e(__('ui.educations_show.apply_now')); ?></a>
                </aside>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('education_view', {
                    education_slug: <?php echo json_encode($education->slug, 15, 512) ?>,
                    provider: <?php echo json_encode($provider ?? ($education->createdByUser?->name ?? null), 15, 512) ?>
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/educations/show.blade.php ENDPATH**/ ?>