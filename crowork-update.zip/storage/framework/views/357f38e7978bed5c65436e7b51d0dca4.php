<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('ui.jobs_page.page_title')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e(__('ui.jobs_page.page_description')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('jobs.index')); ?> <?php $__env->endSlot(); ?>

    <?php $__env->startPush('head'); ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jobs->currentPage() > 1): ?>
            <meta name="robots" content="index,follow">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jobs->previousPageUrl()): ?>
            <link rel="prev" href="<?php echo e($jobs->previousPageUrl()); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jobs->nextPageUrl()): ?>
            <link rel="next" href="<?php echo e($jobs->nextPageUrl()); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php $__env->stopPush(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="cw-content-wide mb-8">
                <p class="cw-kicker mb-2"><?php echo e(__('ui.navigation.jobs')); ?></p>
                <h1 class="cw-display text-3xl md:text-5xl mb-3"><?php echo __('ui.jobs_page.hero_headline'); ?></h1>
                <p class="text-base text-slate-600 max-w-2xl"><?php echo e(__('ui.jobs_page.hero_subheadline')); ?></p>
            </div>

            <?php
                $removeFilterQuery = function (string $key): array {
                    $query = request()->query();
                    unset($query[$key], $query['page']);

                    return $query;
                };

                $activeChips = [];

                if (filled($filters['q'] ?? null)) {
                    $activeChips[] = [
                        'label' => 'Search: ' . $filters['q'],
                        'href' => route('jobs.index', $removeFilterQuery('q')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['city'] ?? null)) {
                    $activeChips[] = [
                        'label' => (string) $filters['city'],
                        'href' => route('jobs.index', $removeFilterQuery('city')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['category'] ?? null)) {
                    $activeChips[] = [
                        'label' => (string) $filters['category'],
                        'href' => route('jobs.index', $removeFilterQuery('category')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['employment_type'] ?? null)) {
                    $activeChips[] = [
                        'label' => \Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', (string) $filters['employment_type'])),
                        'href' => route('jobs.index', $removeFilterQuery('employment_type')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['experience_level'] ?? null)) {
                    $activeChips[] = [
                        'label' => \Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', (string) $filters['experience_level'])),
                        'href' => route('jobs.index', $removeFilterQuery('experience_level')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['salary_min'] ?? null)) {
                    $activeChips[] = [
                        'label' => 'EUR ' . number_format((int) $filters['salary_min']) . '+',
                        'href' => route('jobs.index', $removeFilterQuery('salary_min')),
                        'tone' => 'orange',
                    ];
                }

                if (request()->input('accommodation') == '1') {
                    $activeChips[] = [
                        'label' => 'Accommodation',
                        'href' => route('jobs.index', $removeFilterQuery('accommodation')),
                        'tone' => 'orange',
                    ];
                }

                if (request()->input('visa_support') == '1') {
                    $activeChips[] = [
                        'label' => 'Visa support',
                        'href' => route('jobs.index', $removeFilterQuery('visa_support')),
                        'tone' => 'orange',
                    ];
                }

                if (request()->input('featured') == '1') {
                    $activeChips[] = [
                        'label' => 'Featured',
                        'href' => route('jobs.index', $removeFilterQuery('featured')),
                        'tone' => 'orange',
                    ];
                }

                if (request()->input('urgent') == '1') {
                    $activeChips[] = [
                        'label' => 'Urgent',
                        'href' => route('jobs.index', $removeFilterQuery('urgent')),
                        'tone' => 'orange',
                    ];
                }

                if (filled($filters['language'] ?? null)) {
                    $code = strtoupper((string) $filters['language']);
                    $activeChips[] = [
                        'label' => $languages[$code] ?? $code,
                        'href' => route('jobs.index', $removeFilterQuery('language')),
                        'tone' => 'blue',
                    ];
                }

                if (filled($filters['education_required'] ?? null)) {
                    $activeChips[] = [
                        'label' => (string) $filters['education_required'],
                        'href' => route('jobs.index', $removeFilterQuery('education_required')),
                        'tone' => 'blue',
                    ];
                }
            ?>

            <form
                method="GET"
                action="<?php echo e(route('jobs.index')); ?>"
                data-cw-track-submit="job_search"
                class="mb-6"
                x-data="{
                    desktopAdvancedOpen: false,
                    mobilePanelOpen: false,
                    submitting: false,
                    isDesktop() {
                        return window.matchMedia('(min-width: 768px)').matches;
                    },
                    shouldShowPanel() {
                        return this.isDesktop() ? this.desktopAdvancedOpen : this.mobilePanelOpen;
                    },
                    closePanel() {
                        this.desktopAdvancedOpen = false;
                        this.mobilePanelOpen = false;
                    }
                }"
                @submit="submitting = true"
                @keydown.escape.window="closePanel()"
                   data-cw-filter-form
                   data-cw-filter-panel-id="job-advanced-filters"
            >
                <div class="cw-filter-shell">
                    <div class="cw-surface p-3 md:p-4">
                        <div class="flex items-center justify-between gap-3 mb-3">
                            <div class="text-sm text-slate-600">
                                <span class="font-semibold text-slate-900"><?php echo e(number_format($jobs->total())); ?></span>
                                <span><?php echo e(\Illuminate\Support\Str::plural('result', $jobs->total())); ?></span>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($activeChips) > 0): ?>
                                <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-track-click="job_filter_reset"><?php echo e(__('ui.jobs_page.clear_all_filters')); ?></a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="cw-filter-topbar">
                            <div>
                                <label class="cw-label" for="q"><?php echo e(__('ui.jobs_page.search_button')); ?></label>
                                <input id="q" name="q" value="<?php echo e($filters['q'] ?? request('q')); ?>" class="cw-field" placeholder="<?php echo e(__('ui.jobs_page.search_placeholder')); ?>">
                            </div>
                            <div>
                                <label class="cw-label" for="city"><?php echo e(__('ui.jobs_page.city_label')); ?></label>
                                <select id="city" name="city" class="cw-field">
                                    <option value="">All cities</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city); ?>" <?php if(($filters['city'] ?? request('city')) === $city): echo 'selected'; endif; ?>><?php echo e($city); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                            </div>
                            <div class="flex items-end gap-2">
                                <button
                                    class="cw-button-primary min-w-[120px]"
                                    type="submit"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="<?php echo e(__('ui.jobs_page.search_button')); ?>" data-loading-label="Updating..." aria-live="polite"><?php echo e(__('ui.jobs_page.search_button')); ?></span>
                                </button>
                                <button
                                    type="button"
                                    class="cw-button-secondary hidden md:inline-flex"
                                    data-cw-filter-toggle
                                    aria-controls="job-advanced-filters"
                                    :aria-expanded="desktopAdvancedOpen ? 'true' : 'false'"
                                    @click="desktopAdvancedOpen = !desktopAdvancedOpen"
                                    data-cw-track-click="job_filter_open"
                                >
                                    <span><?php echo e(__('ui.jobs_page.filters_button')); ?></span>
                                    <span class="ml-1 text-xs text-slate-500" x-text="desktopAdvancedOpen ? 'Hide' : 'Show'"></span>
                                </button>
                            </div>
                        </div>

                        <div class="md:hidden mt-3">
                            <button
                                type="button"
                                class="cw-button-secondary w-full"
                                data-cw-filter-open
                                @click="mobilePanelOpen = true"
                                    data-cw-track-click="job_filter_open"
                                aria-controls="job-advanced-filters"
                                :aria-expanded="mobilePanelOpen ? 'true' : 'false'"
                            >
                                <?php echo e(__('ui.jobs_page.advanced_filters_title')); ?>

                            </button>
                        </div>

                        <p class="text-xs text-slate-500 mt-2" x-show="submitting" x-cloak aria-live="polite">Refreshing job results...</p>
                    </div>

                    <div class="md:hidden" x-cloak>
                        <div class="cw-filter-overlay" data-cw-filter-overlay x-show="mobilePanelOpen" x-transition.opacity @click="mobilePanelOpen = false"></div>
                    </div>

                    <div
                        id="job-advanced-filters"
                        x-cloak
                        x-show="shouldShowPanel()"
                        style="display: none;"
                        x-transition:enter="transition ease-out duration-200"
                        x-transition:enter-start="opacity-0 translate-y-2"
                        x-transition:enter-end="opacity-100 translate-y-0"
                        x-transition:leave="transition ease-in duration-150"
                        x-transition:leave-start="opacity-100 translate-y-0"
                        x-transition:leave-end="opacity-0 translate-y-2"
                        class="fixed md:relative inset-x-0 bottom-0 z-[70] md:z-auto"
                        :class="isDesktop() ? 'mt-3' : 'cw-filter-bottom-sheet'"
                    >
                        <div class="cw-filter-panel p-4 md:p-5" :class="isDesktop() ? '' : 'rounded-b-none border-b-0 pb-6'">
                            <div class="flex items-center justify-between mb-3 md:hidden">
                                <h2 class="text-sm font-semibold text-slate-900"><?php echo e(__('ui.jobs_page.advanced_filters_title')); ?></h2>
                                   <button type="button" class="cw-button-secondary !px-3 !py-2 text-xs" data-cw-filter-close aria-controls="job-advanced-filters" @click="mobilePanelOpen = false"><?php echo e(__('ui.jobs_page.close_filters')); ?></button>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-5">
                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.jobs_page.role_section')); ?></p>
                                    <div class="space-y-3">
                                        <div>
                                            <label class="cw-label" for="category"><?php echo e(__('ui.jobs_page.category_label')); ?></label>
                                            <select id="category" name="category" class="cw-field">
                                                <option value="">All categories</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category); ?>" <?php if(($filters['category'] ?? request('category')) === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="cw-label" for="employment_type"><?php echo e(__('ui.jobs_page.employment_type_label')); ?></label>
                                            <select id="employment_type" name="employment_type" class="cw-field">
                                                <option value="">Any type</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $employmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employmentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($employmentType); ?>" <?php if(($filters['employment_type'] ?? request('employment_type')) === $employmentType): echo 'selected'; endif; ?>><?php echo e(\Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', $employmentType))); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="cw-label" for="experience_level"><?php echo e(__('ui.jobs_page.experience_label')); ?></label>
                                            <select id="experience_level" name="experience_level" class="cw-field">
                                                <option value="">Any level</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $experienceLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experienceLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($experienceLevel); ?>" <?php if(($filters['experience_level'] ?? request('experience_level')) === $experienceLevel): echo 'selected'; endif; ?>><?php echo e(\Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', $experienceLevel))); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.jobs_page.compensation_section')); ?></p>
                                    <div class="space-y-3">
                                        <div>
                                            <label class="cw-label" for="salary_min"><?php echo e(__('ui.jobs_page.salary_min_label')); ?></label>
                                            <input id="salary_min" name="salary_min" value="<?php echo e($filters['salary_min'] ?? request('salary_min')); ?>" class="cw-field" type="number" min="0" placeholder="<?php echo e(__('ui.jobs_page.salary_placeholder')); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.jobs_page.relocation_section')); ?></p>
                                    <div class="space-y-3">
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                            <input type="checkbox" name="accommodation" value="1" class="rounded border-slate-300" <?php if(($filters['accommodation'] ?? request('accommodation'))): echo 'checked'; endif; ?>> 
                                            <?php echo e(__('ui.jobs_page.accommodation_label')); ?>

                                        </label>
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                            <input type="checkbox" name="visa_support" value="1" class="rounded border-slate-300" <?php if(($filters['visa_support'] ?? request('visa_support'))): echo 'checked'; endif; ?>> 
                                            <?php echo e(__('ui.jobs_page.visa_support_label')); ?>

                                        </label>
                                    </div>
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.jobs_page.qualifications_section')); ?></p>
                                    <div class="space-y-3">
                                        <div>
                                            <label class="cw-label" for="language"><?php echo e(__('ui.jobs_page.language_label')); ?></label>
                                            <select id="language" name="language" class="cw-field">
                                                <option value="">Any language</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($code); ?>" <?php if(($filters['language'] ?? request('language')) === $code): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="cw-label" for="education_required"><?php echo e(__('ui.jobs_page.education_label')); ?></label>
                                            <select id="education_required" name="education_required" class="cw-field">
                                                <option value="">Any education</option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $educationRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educationRequired): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($educationRequired); ?>" <?php if(($filters['education_required'] ?? request('education_required')) === $educationRequired): echo 'selected'; endif; ?>><?php echo e($educationRequired); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <p class="cw-filter-heading"><?php echo e(__('ui.jobs_page.visibility_section')); ?></p>
                                    <div class="space-y-3">
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                            <input type="checkbox" name="featured" value="1" class="rounded border-slate-300" <?php if(($filters['featured'] ?? request('featured'))): echo 'checked'; endif; ?>> 
                                            <?php echo e(__('ui.jobs_page.featured_label')); ?>

                                        </label>
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-700">
                                            <input type="checkbox" name="urgent" value="1" class="rounded border-slate-300" <?php if(($filters['urgent'] ?? request('urgent'))): echo 'checked'; endif; ?>> 
                                            <?php echo e(__('ui.jobs_page.urgent_label')); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-5 flex flex-wrap items-center gap-2">
                                <button
                                    class="cw-button-primary"
                                    type="submit"
                                    data-cw-track-click="job_filter_apply"
                                    :disabled="submitting"
                                >
                                    <span data-cw-submit-label data-default-label="<?php echo e(__('ui.jobs_page.apply_filters')); ?>" data-loading-label="Applying..." aria-live="polite"><?php echo e(__('ui.jobs_page.apply_filters')); ?></span>
                                </button>
                                <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-secondary" data-cw-track-click="job_filter_reset">Reset</a>
                                   <button type="button" class="cw-button-secondary md:hidden" data-cw-filter-close aria-controls="job-advanced-filters" @click="mobilePanelOpen = false"><?php echo e(__('ui.jobs_page.done_filters')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>

                <button type="button" class="cw-button-primary cw-filter-fab md:hidden" data-cw-filter-open aria-controls="job-advanced-filters" @click="mobilePanelOpen = true">
                    <?php echo e(__('ui.jobs_page.filters_button')); ?>

                </button>
            </form>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($activeChips) > 0): ?>
                <div class="mb-5 flex flex-wrap items-center gap-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $activeChips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-chip','data' => ['href' => $chip['href'],'label' => $chip['label'],'tone' => $chip['tone']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['href']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['label']),'tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chip['tone'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8)): ?>
<?php $attributes = $__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8; ?>
<?php unset($__attributesOriginalb921c1d8f3114956c1eefb7c2c21f5b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8)): ?>
<?php $component = $__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8; ?>
<?php unset($__componentOriginalb921c1d8f3114956c1eefb7c2c21f5b8); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-secondary !px-3 !py-2 text-xs"><?php echo e(__('ui.jobs_page.clear_all_filters')); ?></a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(count($activeChips) === 0): ?>
                <!-- Why CroWork section -->
                <div class="mb-8">
                    <h2 class="text-2xl md:text-3xl font-semibold text-slate-900 mb-6"><?php echo e(__('ui.jobs_page.why_crowork_title')); ?></h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                        <!-- Transparent listings -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-indigo-100">
                                        <svg class="h-6 w-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.jobs_page.why_crowork.transparent_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.jobs_page.why_crowork.transparent_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Faster applications -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-blue-100">
                                        <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.jobs_page.why_crowork.faster_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.jobs_page.why_crowork.faster_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Modern hiring -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-purple-100">
                                        <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.jobs_page.why_crowork.modern_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.jobs_page.why_crowork.modern_desc')); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Multilingual support -->
                        <div class="cw-surface p-6 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="flex items-center justify-center h-12 w-12 rounded-lg bg-emerald-100">
                                        <svg class="h-6 w-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 00.948-.684l1.498-4.493a1 1 0 011.502-.684l1.498 4.493a1 1 0 00.948.684H19a2 2 0 012 2v1M3 5a2 2 0 012-2h.5a1 1 0 01.855.468L7.5 4m0 0l1.5-2a1 1 0 011.414 0m0 0l1.5 2m-9 0h2m6 0h2"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <h3 class="text-base font-semibold text-slate-900 mb-1"><?php echo e(__('ui.jobs_page.why_crowork.multilingual_title')); ?></h3>
                                    <p class="text-sm text-slate-600"><?php echo e(__('ui.jobs_page.why_crowork.multilingual_desc')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php echo $__env->make('jobs._results', ['jobs' => $jobs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('job_search_results_view', {
                    page: <?php echo e($jobs->currentPage()); ?>,
                    total_results: <?php echo e($jobs->total()); ?>

                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/jobs/index.blade.php ENDPATH**/ ?>