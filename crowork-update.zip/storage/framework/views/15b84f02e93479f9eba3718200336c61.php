<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="cw-surface p-6 md:p-8">
        <p class="cw-kicker mb-2">Sign in</p>
        <h1 class="text-3xl md:text-4xl font-semibold text-slate-900 mb-2">Welcome back</h1>
        <p class="text-sm text-slate-600 mb-6">Continue your CroWork journey in two calm steps.</p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
            <div class="mb-4 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl p-3"><?php echo e(session('status')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4" x-data="{ step: <?php echo e($errors->has('password') ? 2 : 1); ?> }">
            <?php echo csrf_field(); ?>

            <div class="flex items-center justify-between text-xs uppercase tracking-[0.08em] text-slate-500">
                <span :class="step === 1 ? 'text-slate-900 font-semibold' : ''">Step 1 · Identity</span>
                <span :class="step === 2 ? 'text-slate-900 font-semibold' : ''">Step 2 · Access</span>
            </div>

            <div x-show="step === 1" x-transition.opacity.duration.150ms>
                <label for="email" class="cw-label">Email</label>
                <input id="email" class="cw-field" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username" placeholder="alex@example.com" />
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <button type="button" class="cw-button-primary mt-4" @click="step = 2">Continue</button>
            </div>

            <div x-show="step === 2" x-transition.opacity.duration.150ms x-cloak>
                <div class="mb-3 text-xs text-slate-500">Signing in as <span class="font-medium text-slate-700"><?php echo e(old('email') ?: 'your account'); ?></span></div>

                <label for="password" class="cw-label">Password</label>
                <input id="password" class="cw-field" type="password" name="password" required autocomplete="current-password" />
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <label class="inline-flex items-center gap-2 text-sm text-slate-700 mt-3">
                    <input type="checkbox" name="remember" class="rounded border-slate-300" />
                    Remember me
                </label>

                <div class="flex flex-wrap items-center justify-between gap-2 mt-4">
                    <button type="button" class="cw-button-secondary" @click="step = 1">Back</button>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Route::has('password.request')): ?>
                        <a class="text-sm text-slate-600 hover:text-slate-900" href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <button type="submit" class="cw-button-primary">Sign in</button>
                </div>
            </div>
        </form>

        <p class="text-sm text-slate-600 mt-5">No account? <a href="<?php echo e(route('register')); ?>" class="text-slate-900 font-medium">Create one</a></p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/auth/login.blade.php ENDPATH**/ ?>