
<?php
    // Fetch featured jobs with employer relationship eagerly loaded
    $featuredJobs = \App\Models\Job::where('is_featured', true)
        ->with('employer')
        ->latest()
        ->take(6)
        ->get();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($featuredJobs->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['title' => __('ui.homepage.empty_state.no_jobs'),'icon' => 'star']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('ui.homepage.empty_state.no_jobs')),'icon' => 'star']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php else: ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $featuredJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $employer = $job->employer;
                $company_href = null;
                if ($employer && $employer instanceof \App\Models\Employer && $employer->getKey() && $employer->getRouteKey()) {
                    try {
                        $company_href = route('companies.show', $employer);
                    } catch (Exception $e) {
                        $company_href = null;
                    }
                }
            ?>
            <?php if (isset($component)) { $__componentOriginalbb7abfc421304865208a8164802344c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb7abfc421304865208a8164802344c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.job-card','data' => ['title' => $job->title,'company' => $employer?->company_name,'companyHref' => $company_href,'city' => $job->city,'salaryMin' => $job->salary_min,'salaryMax' => $job->salary_max,'salaryCurrency' => $job->salary_currency,'salaryPeriod' => $job->salary_period,'employmentType' => $job->employment_type,'experienceLevel' => $job->experience_level,'educationRequired' => $job->education_required,'positionsAvailable' => $job->positions_available,'workingHours' => $job->working_hours,'startDate' => $job->start_date,'startFlexibility' => $job->start_flexibility,'accommodationProvided' => $job->accommodation_provided,'visaSupport' => $job->visa_support,'isFeatured' => $job->is_featured,'isUrgent' => $job->is_urgent,'languages' => $job->languages,'postedAt' => $job->created_at,'href' => route('jobs.show', $job)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('job-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->title),'company' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employer?->company_name),'company_href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company_href),'city' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->city),'salary_min' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_min),'salary_max' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_max),'salary_currency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_currency),'salary_period' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->salary_period),'employment_type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->employment_type),'experience_level' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->experience_level),'education_required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->education_required),'positions_available' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->positions_available),'working_hours' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->working_hours),'start_date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->start_date),'start_flexibility' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->start_flexibility),'accommodation_provided' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->accommodation_provided),'visa_support' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->visa_support),'is_featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->is_featured),'is_urgent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->is_urgent),'languages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->languages),'posted_at' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->created_at),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('jobs.show', $job))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb7abfc421304865208a8164802344c3)): ?>
<?php $attributes = $__attributesOriginalbb7abfc421304865208a8164802344c3; ?>
<?php unset($__attributesOriginalbb7abfc421304865208a8164802344c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb7abfc421304865208a8164802344c3)): ?>
<?php $component = $__componentOriginalbb7abfc421304865208a8164802344c3; ?>
<?php unset($__componentOriginalbb7abfc421304865208a8164802344c3); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/components/featured-jobs.blade.php ENDPATH**/ ?>