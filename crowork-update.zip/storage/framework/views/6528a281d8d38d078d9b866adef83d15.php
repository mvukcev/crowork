<style>
    /* Keep topbar controls clickable on mobile when sidebar overlay is open. */
    @media (max-width: 1023px) {
        .fi-sidebar-close-overlay {
            top: 4rem;
        }
    }
</style>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/filament/partials/topbar-overlay-fix.blade.php ENDPATH**/ ?>