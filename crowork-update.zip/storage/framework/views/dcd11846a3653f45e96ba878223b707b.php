<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title',
    'company' => null,
    'company_href' => null,
    'city' => null,
    'salary_min' => null,
    'salary_max' => null,
    'salary_currency' => 'EUR',
    'salary_period' => 'month',
    'employment_type' => null,
    'experience_level' => null,
    'education_required' => null,
    'positions_available' => null,
    'working_hours' => null,
    'start_date' => null,
    'start_flexibility' => null,
    'accommodation_provided' => false,
    'visa_support' => false,
    'is_featured' => false,
    'is_urgent' => false,
    'languages' => [],
    'posted_at' => null,
    'href' => '#',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title',
    'company' => null,
    'company_href' => null,
    'city' => null,
    'salary_min' => null,
    'salary_max' => null,
    'salary_currency' => 'EUR',
    'salary_period' => 'month',
    'employment_type' => null,
    'experience_level' => null,
    'education_required' => null,
    'positions_available' => null,
    'working_hours' => null,
    'start_date' => null,
    'start_flexibility' => null,
    'accommodation_provided' => false,
    'visa_support' => false,
    'is_featured' => false,
    'is_urgent' => false,
    'languages' => [],
    'posted_at' => null,
    'href' => '#',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $salaryDisplay = null;
    if (!is_null($salary_min) || !is_null($salary_max)) {
        $currency = strtoupper((string) $salary_currency);
        $period = strtolower((string) $salary_period) === 'hour' ? 'hour' : 'month';
        $periodLabel = __('jobs.' . $period);

        if (!is_null($salary_min) && !is_null($salary_max)) {
            $salaryDisplay = __('jobs.salary_range', [
                'currency' => $currency,
                'min' => number_format($salary_min),
                'max' => number_format($salary_max),
                'period' => $periodLabel,
            ]);
        } elseif (!is_null($salary_min)) {
            $salaryDisplay = __('jobs.salary_from', [
                'currency' => $currency,
                'amount' => number_format($salary_min),
                'period' => $periodLabel,
            ]);
        } else {
            $salaryDisplay = __('jobs.salary_up_to', [
                'currency' => $currency,
                'amount' => number_format($salary_max),
                'period' => $periodLabel,
            ]);
        }
    }

    $languageValues = [];
    if (is_array($languages)) {
        $languageValues = $languages;
    } elseif (is_string($languages) && trim($languages) !== '') {
        $decoded = json_decode($languages, true);
        $languageValues = is_array($decoded) ? $decoded : preg_split('/[\n,]+/', $languages);
    }

    $languageValues = array_values(array_filter(array_map(fn ($lang) => trim((string) $lang), $languageValues)));
    $languageText = count($languageValues) ? implode(', ', array_slice($languageValues, 0, 3)) : null;

    $employmentTypeText = $employment_type ? \Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', $employment_type)) : null;
    $experienceLevelText = $experience_level ? \Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', $experience_level)) : null;
    $educationText = $education_required ?: null;
    $positionsText = is_numeric($positions_available) ? trans_choice('jobs.position_count', (int) $positions_available, ['count' => (int) $positions_available]) : null;
    $workingHoursText = $working_hours ?: null;
    $startDateText = $start_date ? __('jobs.start_short', ['date' => \Illuminate\Support\Carbon::parse($start_date)->format('M j')]) : null;
    $startFlexibilityText = $start_flexibility ?: null;
?>

<article class="cw-surface p-5 block cw-hover-lift">
    <div class="flex items-start justify-between gap-3 mb-2">
        <div>
            <p class="text-xs text-slate-500 mb-1">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($company_href && $company): ?>
                    <a href="<?php echo e($company_href); ?>" class="hover:text-slate-900 underline-offset-2 hover:underline"><?php echo e($company); ?></a>
                <?php else: ?>
                    <?php echo e($company ?: __('jobs.employer_fallback')); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($city): ?>
                    <span> · <?php echo e($city); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
            <h3 class="text-lg font-semibold text-slate-900 leading-tight"><a href="<?php echo e($href); ?>" class="hover:text-slate-700"><?php echo e($title); ?></a></h3>
        </div>
        <div class="flex flex-col gap-1 items-end">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($is_urgent): ?>
                <span class="cw-chip text-red-800 bg-red-50 border-red-200"><?php echo e(__('jobs.urgent_tag')); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($is_featured): ?>
                <span class="cw-chip text-indigo-800 bg-indigo-50 border-indigo-200"><?php echo e(__('jobs.featured_tag')); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($salaryDisplay): ?>
        <p class="text-sm text-slate-700 mb-2"><?php echo e($salaryDisplay); ?></p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="flex flex-wrap items-center gap-2 mt-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($employmentTypeText): ?>
            <span class="cw-chip"><?php echo e($employmentTypeText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($experienceLevelText): ?>
            <span class="cw-chip"><?php echo e($experienceLevelText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($educationText): ?>
            <span class="cw-chip"><?php echo e($educationText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($positionsText): ?>
            <span class="cw-chip"><?php echo e($positionsText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($workingHoursText): ?>
            <span class="cw-chip"><?php echo e($workingHoursText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($startDateText): ?>
            <span class="cw-chip"><?php echo e($startDateText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($startFlexibilityText): ?>
            <span class="cw-chip"><?php echo e($startFlexibilityText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($languageText): ?>
            <span class="cw-chip"><?php echo e($languageText); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($accommodation_provided): ?>
            <span class="cw-chip text-amber-800 bg-amber-50 border-amber-200"><?php echo e(__('jobs.accommodation')); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($visa_support): ?>
            <span class="cw-chip text-emerald-800 bg-emerald-50 border-emerald-200"><?php echo e(__('jobs.visa_support')); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($posted_at): ?>
            <span class="cw-chip"><?php echo e(__('jobs.posted_short', ['time' => \Carbon\Carbon::parse($posted_at)->diffForHumans()])); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="mt-4 flex flex-wrap gap-2">
        <a href="<?php echo e($href); ?>" class="cw-button-secondary"><?php echo e(__('ui.jobs_page.view_role')); ?></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($company_href): ?>
            <a href="<?php echo e($company_href); ?>" class="cw-button-secondary"><?php echo e(__('ui.jobs_page.company_profile')); ?></a>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</article>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/components/job-card.blade.php ENDPATH**/ ?>