
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($resource['title']); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('description', null, []); ?> <?php echo e($resource['description']); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('canonical', null, []); ?> <?php echo e(route('resources.show', $resource['slug'])); ?> <?php $__env->endSlot(); ?>

    <?php $__env->startPush('head'); ?>
        <script type="application/ld+json"><?php echo json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => route('home'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => __('resources.headline'),
                    'item' => route('resources.index'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $resource['title'],
                    'item' => route('resources.show', $resource['slug']),
                ],
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
    <?php $__env->stopPush(); ?>

    <section class="cw-section">
        <div class="cw-container">
            <div class="mb-6 text-sm text-slate-500">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-slate-900"><?php echo e(__('ui.navigation.home')); ?></a>
                <span class="mx-1">/</span>
                <a href="<?php echo e(route('resources.index')); ?>" class="hover:text-slate-900"><?php echo e(__('resources.headline')); ?></a>
                <span class="mx-1">/</span>
                <span class="text-slate-700"><?php echo e($resource['title']); ?></span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_340px] gap-10 items-start">
                <div class="space-y-8">
                    <article class="cw-surface p-8 rounded-2xl shadow-md bg-white/90">
                        <p class="cw-kicker mb-3 text-violet-600 font-semibold"><?php echo e($resource['kicker']); ?></p>
                        <h1 class="cw-display text-4xl md:text-6xl mb-4 font-bold"><?php echo e($resource['title']); ?></h1>
                        <p class="text-lg text-slate-700 leading-relaxed mb-6"><?php echo e($resource['intro']); ?></p>
                    </article>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $resource['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="cw-surface p-7 rounded-xl bg-white/80 shadow border-l-4 border-violet-200">
                            <h2 class="text-2xl font-semibold text-violet-700 mb-3"><?php echo e($section['title']); ?></h2>
                            <div class="space-y-3 text-slate-700">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $section['body']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($paragraph); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <aside class="mt-8 lg:mt-0 space-y-6 lg:sticky lg:top-24">
                    <div class="cw-surface p-6 rounded-xl bg-white/90 shadow">
                        <h2 class="text-lg font-semibold text-violet-700 mb-3"><?php echo e(__('resources.show.guide_topics')); ?></h2>
                        <div class="flex flex-col gap-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navResource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a
                                    href="<?php echo e(route('resources.show', $navResource['slug'])); ?>"
                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                        'cw-button-secondary text-left' => true,
                                        'border-violet-700 text-violet-700 font-bold' => $navResource['slug'] === $resource['slug'],
                                    ]); ?>"
                                >
                                    <?php echo e($navResource['title']); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                    <div class="cw-surface p-6 rounded-xl bg-gradient-to-r from-violet-50 to-white shadow">
                        <h2 class="text-lg font-semibold text-violet-700 mb-3"><?php echo e(__('resources.show.next_steps')); ?></h2>
                        <div class="space-y-3 text-sm text-slate-700">
                            <p><?php echo e(__('resources.show.next_steps_copy')); ?></p>
                            <a href="<?php echo e(route('jobs.index')); ?>" class="cw-button-primary w-full text-center"><?php echo e(__('resources.cta.browse_jobs')); ?></a>
                            <a href="<?php echo e(route('contact')); ?>" class="cw-button-secondary w-full text-center"><?php echo e(__('resources.cta.contact')); ?></a>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                window.cwTrack?.('page_view', {
                    page_type: 'resource_detail',
                    resource_slug: <?php echo json_encode($resource['slug'], 15, 512) ?>
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/pages/resources/show.blade.php ENDPATH**/ ?>