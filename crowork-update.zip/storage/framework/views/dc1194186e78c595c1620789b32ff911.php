<?php $__env->startSection('title', __('errors.403.title')); ?>

<section class="cw-section min-h-screen flex items-center justify-center">
    <div class="cw-container max-w-lg text-center">
        <div class="mb-6">
            <div class="text-6xl font-bold text-amber-600 mb-4">403</div>
            <h1 class="text-4xl font-bold text-slate-900 mb-2"><?php echo e(__('errors.403.heading')); ?></h1>
            <p class="text-lg text-slate-600 mb-6">
                <?php echo e(__('errors.403.body')); ?>

            </p>
        </div>

        <div class="space-y-3">
            <a href="<?php echo e(route('home')); ?>" class="cw-button-accent block">
                <?php echo e(__('errors.actions.return_home')); ?>

            </a>
            <a href="javascript:history.back()" class="cw-button-secondary block">
                <?php echo e(__('errors.actions.go_back')); ?>

            </a>
        </div>
    </div>
</section>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/errors/403.blade.php ENDPATH**/ ?>