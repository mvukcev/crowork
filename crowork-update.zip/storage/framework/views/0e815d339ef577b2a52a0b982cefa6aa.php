<div class="space-y-4 text-sm">
    <div>
        <h3 class="text-base font-semibold text-gray-900"><?php echo e($job->title); ?></h3>
        <p class="mt-1 text-gray-600">
            <?php echo e($job->location_city); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($job->category): ?>
                · <?php echo e($job->category); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($job->contract_type): ?>
                · <?php echo e(\Illuminate\Support\Str::headline(str_replace(['-', '_'], ' ', $job->contract_type))); ?>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </p>
    </div>

    <div class="rounded-lg bg-gray-50 p-3 text-gray-700 space-y-1">
        <div><strong>Status:</strong> <?php echo e(ucfirst($job->status)); ?></div>
        <div><strong>Salary:</strong> <?php echo e($job->formatted_salary); ?></div>
        <div><strong>Experience:</strong> <?php echo e($job->experience_level ? \Illuminate\Support\Str::headline($job->experience_level) : 'Not specified'); ?></div>
        <div><strong>Open positions:</strong> <?php echo e($job->positions_available ?: 'Not specified'); ?></div>
        <div><strong>Accommodation:</strong> <?php echo e($job->accommodation_provided ? 'Provided' : 'Not provided'); ?></div>
        <div><strong>Visa support:</strong> <?php echo e($job->visa_support ? 'Yes' : 'No'); ?></div>
        <div><strong>Expires:</strong> <?php echo e($job->expires_at?->format('M d, Y H:i') ?? 'Not set'); ?></div>
    </div>

    <div class="prose prose-sm max-w-none text-gray-800">
        <?php echo $job->description; ?>

    </div>
</div>
<?php /**PATH /Users/matevukcevic/VisualCode/crowork/resources/views/filament/employer/job-preview.blade.php ENDPATH**/ ?>