<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Indexes for job applications to prevent N+1 queries
        Schema::table('job_applications', function (Blueprint $table) {
            // Index on job_id for employer dashboard queries
            if (!$this->indexExists('job_applications', 'job_applications_job_id_index')) {
                $table->index('job_id');
            }

            // Index on worker_id for worker dashboard
            if (!$this->indexExists('job_applications', 'job_applications_worker_id_index')) {
                $table->index('worker_id');
            }

            // Composite index for status queries
            if (!$this->indexExists('job_applications', 'job_applications_status_created_at_index')) {
                $table->index(['status', 'created_at']);
            }
        });

        // Indexes for jobs table
        Schema::table('job_postings', function (Blueprint $table) {
            // Index for published/active job queries
            if (!$this->indexExists('job_postings', 'job_postings_status_published_at_index')) {
                $table->index(['status', 'published_at']);
            }

            // Index for employer queries
            if (!$this->indexExists('job_postings', 'job_postings_employer_id_index')) {
                $table->index('employer_id');
            }

            // Index for expiration checks
            if (!$this->indexExists('job_postings', 'job_postings_expires_at_index')) {
                $table->index('expires_at');
            }
        });

        // Indexes for users table
        Schema::table('users', function (Blueprint $table) {
            // Index for role-based queries
            if (!$this->indexExists('users', 'users_role_index')) {
                $table->index('role');
            }
        });

        // Indexes for audit logs
        Schema::table('audit_logs', function (Blueprint $table) {
            // Index for historical queries
            if (!$this->indexExists('audit_logs', 'audit_logs_user_id_created_at_index')) {
                $table->index(['user_id', 'created_at']);
            }

            // Index for action filtering
            if (!$this->indexExists('audit_logs', 'audit_logs_action_index')) {
                $table->index('action');
            }
        });

        // Indexes for notifications
        Schema::table('notifications', function (Blueprint $table) {
            // Index for unread notification queries
            if (!$this->indexExists('notifications', 'notifications_notifiable_id_read_at_index')) {
                $table->index(['notifiable_id', 'read_at']);
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('job_applications', function (Blueprint $table) {
            $table->dropIndexIfExists('job_applications_job_id_index');
            $table->dropIndexIfExists('job_applications_worker_id_index');
            $table->dropIndexIfExists('job_applications_status_created_at_index');
        });

        Schema::table('job_postings', function (Blueprint $table) {
            $table->dropIndexIfExists('job_postings_status_published_at_index');
            $table->dropIndexIfExists('job_postings_employer_id_index');
            $table->dropIndexIfExists('job_postings_expires_at_index');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndexIfExists('users_role_index');
        });

        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropIndexIfExists('audit_logs_user_id_created_at_index');
            $table->dropIndexIfExists('audit_logs_action_index');
        });

        Schema::table('notifications', function (Blueprint $table) {
            $table->dropIndexIfExists('notifications_notifiable_id_read_at_index');
        });
    }

    /**
     * Check if index exists on table (helper for safe migration)
     */
    private function indexExists(string $table, string $indexName): bool
    {
        try {
            $indexes = Schema::getConnection()
                ->getDoctrineSchemaManager()
                ->listTableIndexes($table);
            return isset($indexes[$indexName]);
        } catch (\Exception $e) {
            return false;
        }
    }
};
